# Starlight’s Atlas — 0.2.1
A cosmic lore library for Desi, from Dad & Nova.

## Studio connection — 0.2.1
Install Starlight’s Studio to use the new sending action. Dream has visible Send / update Atlas and Send to Studio buttons beneath its top action row. It sends PNG artwork (with background or transparent) and MP4 drawing-process replay; newly exported replays contain no added label. Atlas offers Send copy to Studio beneath an occupied image slot in Edit reference. Studio stores copies in Incoming until placed or discarded. All original artwork/lore stays in its owning app.

Install this APK as an update without uninstalling. Build/signature checks and Atlas data/transfer tests passed; the new Studio handoff has not been run on an Android device here.

## Operation Integrate — Dream ↔ Atlas (0.2.0)
Install BOTH updated APKs over the existing apps. Do not uninstall or clear app data. Existing art and lore stay in their respective apps. Export important .dream and .atlas backups first.

### Dream → Atlas
1. Open the drawing. If the toolbar is hidden, tap **Show tools**.
2. Tap **Atlas** in the top action strip (scroll the strip sideways if needed).
3. Choose **Send to Starlight’s Atlas**. Apply or cancel any floating selection first.
4. Atlas receives a clean PNG copy of the visible artwork, including the canvas background. Its **Incoming from Dream** button keeps unplaced artwork available after closing/reopening Atlas.
5. Choose a reference (or create one), then its image slot. Replacing an occupied slot asks first. Saving returns to Dream and remembers the destination.

Incoming supports characters, world versions, species, worlds, powers, events, notebook/lore entries, and the new Locations and Items shelves. Full reference, mini design and accessory slots are supported, with extra slots as needed. Canceling the picker keeps the incoming copy. Discard removes only that incoming copy. At most 20 incoming images can wait at once.

### Atlas → Dream → Update Atlas copy
1. Open a reference, tap **Edit reference**, and find its image slot.
2. Tap **Create in Dream** or **Edit in Dream**. An existing linked original opens after confirmation. An unlinked image is copied into a new Dream project; an empty slot starts a blank square canvas. A missing linked project offers a new project from the saved Atlas copy.
3. Draw normally. Dream owns and saves all editable layers.
4. Tap **Atlas → Update Atlas copy**. Atlas offers the linked destination and asks before replacing its image. You can choose another destination instead.

Updating is an explicit action, not automatic on every brush stroke. A Dream project remembers one return destination at a time; sending to another slot makes that the latest destination. Atlas slots keep links to their Dream originals. Neither app writes directly to the other app’s private project/lore files. Transfers are read-only PNG copies; both apps remain usable when the other is absent or outdated, with a message for unavailable integration actions. No accounts, subscription, ads or internet permission.

Links are local to this phone. Atlas backups include the link information and images, but cannot restore Dream’s missing layered projects. Dream’s normal .dream export preserves artwork/layers; its local return-destination sidecar is not included. After moving or restoring projects, send a copy again to establish the desired link. Incoming copies are not included in Atlas backups until assigned to a slot. World-version slots are separate from base-character images.

### Verification and Desi’s first test
Both apps compile, package, align and verify with their existing signing keys and higher version codes. JavaScript syntax, 13 existing model checks, handoff model checks and five transfer-flow checks passed. Transfer checks cover storage failure, cancellation, stale/deleted destinations, double taps, copy isolation and completion order, using storage/native-call test doubles. The browser runtime download failed; no new visual browser test or Android-device round trip was run here.

On the phone: send one drawing into an empty character slot, edit that slot in Dream, add a mark and send Update Atlas copy. Check the same slot changes and Dream’s layers remain editable. Also cancel one replacement and return to Incoming, and try a world-version slot to check its base image stays unchanged.


## Install
Open **Starlights_Atlas.apk** on an Android phone (Android 8 or newer). This is a separate app: it does not replace or change Starlight’s Dream. It works offline and has no ads, subscriptions, accounts, or internet permission. It uses the phone’s Android System WebView for its local interface.

## First few references
1. Open **Species** and add a species. Describe appearance, behavior, diet and restrictions, magical preferences, side effects, interactions around others, lifespan, habitat, culture, strengths, and weaknesses. Attach a species base image and other reference pictures.
2. Open **Characters** and add a base character. Add name, nickname, age, birthday, gender, sexual preference, pronouns, species reference, appearance, personality, history, motivations, fears, abilities, weaknesses, relationships, and notes. All fields are optional and accept your own wording.
3. In **Reference images**, add the full reference, mini design image, and three weapon/accessory images. **Another image slot** adds more. Rename any image label to fit your work. Photos are copied into the app; the phone originals remain unchanged. Imported reference copies have a maximum 2048-pixel long edge.
4. Use **Custom field** for anything missing: voice, height, allergies, theme song, handedness, or another detail. Text changes save automatically; **Done** opens the readable reference page. Check for **Saved on this device** before leaving.

## Worlds without rewriting the original
Create a world under **Worlds**, including its setting, calendar, magic, technology, cultures, locations, and rules. Open that world and choose **Add character version**, or open a base character and choose **World version**.

A world version links to its base and world. Untouched detail fields inherit the current base values. Typing in a field creates an override for that version only. **Reset to base** removes that override. You may intentionally override with an empty value. Later base edits flow into fields that still inherit.

Species also inherits unless a different species is selected for that world version. Images inherit until the version has its own images; a version’s own gallery replaces the displayed inherited gallery. The base remains accessible as a link. The version’s title, status, tags, and generic connections are its own, not inherited.

## Connected lore and future events
**Link** connects an existing reference to another reference, with your own relationship label: Rival, Future event, Wields, Born in, Transforms into, or anything useful. The linked reference opens when tapped. **Mentioned in** shows reverse links automatically.

A character’s **Future event** button creates an event already linked to them. Open **Timeline** to add events, world connections, custom in-world dates, summaries, consequences, and foreshadowing. Use the numeric **Chronology / chapter number** field to sort events; dates can use any invented calendar. A base character’s page lists events directly linked to that character. Link versions separately when an event belongs to just one world.

## Power dynamics
Create a category, then open it and add a **Subcategory**. Categories can nest several levels. Each can describe its rank, requirements, limitations, costs, counters, and interactions. The parent selector prevents loops.

Use **Assign character** on a category to assign a base character or a world version. A parent category includes members of its nested subcategories. A character can have multiple power-category links. These are descriptive categories; the app does not calculate combat outcomes or invent rankings.

## Extra things to discover
- **Bookmarks** bring favorite references to the top of the home shelf.
- **Search every shelf** searches names, tags, and stored detail text. Individual shelves include status and favorite filters. Inherited text is visible on a version’s reference page; global search indexes its stored overrides and the base separately.
- **Notebook** keeps freeform lore and ideas with pictures and links.
- **A little spark** offers rotating writing prompts. Keep a prompt directly as a notebook entry. These are built-in prompts, not an online AI service.
- **Copy reference text** copies a readable reference for messages or other apps.
- **Duplicate** makes an independent reference copy; use World version when you want inheritance.
- **Trash** is recoverable. Deleting a reference never permanently removes its entry or link identity. Restore it from the keeper’s desk. References to something in Trash show that it is in Trash.
- Larger text settings are available in the keeper’s desk.

## Back up the whole library
Open **☰ → Export full backup**. Choose **Save to Downloads** or **Choose folder**. Downloads are placed in **Downloads / Starlights Atlas** on Android 10 or later. Android 8–9 use the folder picker. A backup includes references, images, links, world versions, and Trash in a portable `.atlas` file. The current backup size limit is 256 MB.

**Import backup replaces the current library after confirmation.** The app keeps one local pre-import library. **Recover pre-import library** swaps back to that library; the displaced library then becomes the recoverable copy. Imported image identities are remapped so a backup image cannot overwrite an image needed by the recovery library.

Automatic saving stays inside the app. Export copies regularly: uninstalling the app or clearing its data removes the local library. There is no cloud sync. World/reference images and lore remain on your phone unless you export them.

## Verification and first phone check
The APK compiled successfully and passed signature, alignment, package, and archive integrity checks. Thirteen executable model checks passed, covering base preservation, inherited updates, reset behavior, power ancestry and cycle prevention, reverse links, reference identity through Trash, backup record validation, and distinct IDs. JavaScript syntax was checked.

The full browser UI test script is included in the source but could not run: the available headless browser binary was unusable and its replacement download failed. No Android phone/emulator was available. Image picking, Android backup destinations, layout, and actual on-device persistence have not yet been runtime-verified. This is the first test build, not a claim that all device behavior has passed.

Before entering a large lore collection, make a small character with five images, create a world version, change one detail, close/reopen the app, export a backup, then import that backup and verify the images and links. The base detail should remain unchanged. Tell us where anything behaves differently than expected.
