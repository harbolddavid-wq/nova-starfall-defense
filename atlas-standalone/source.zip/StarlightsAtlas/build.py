from pathlib import Path
import argparse
import concurrent.futures
import hashlib
import json
import shutil
import subprocess
import urllib.request
import zipfile

PROJECT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Build the signed, offline Starlight’s Atlas APK.')
parser.add_argument('--toolchain',type=Path,default=PROJECT/'.toolchain')
parser.add_argument('--output',type=Path,default=PROJECT.parent/'Starlights_Atlas.apk')
args=parser.parse_args()
toolchain=args.toolchain.resolve()
output=args.output.resolve()
toolchain.mkdir(parents=True,exist_ok=True)
output.parent.mkdir(parents=True,exist_ok=True)
sdk=toolchain/'sdk'
tools=sdk/'build-tools/35.0.0'
platform=sdk/'platforms/android-35/android.jar'
compiler=toolchain/'ecj-3.39.0.jar'
lock=json.loads((PROJECT/'toolchain-lock.json').read_text())

def acquire(package):
    if package['package']=='ecj':
        ready=compiler
    elif package['package'].startswith('platforms'):
        ready=platform
    else:
        ready=tools/'aapt2'
    if ready.exists(): return
    archive_path=toolchain/Path(package['url']).name
    digest=hashlib.new(package['checksum_type'])
    with urllib.request.urlopen(package['url'],timeout=60) as response,archive_path.open('wb') as stream:
        while chunk:=response.read(1024*1024):
            stream.write(chunk);digest.update(chunk)
    assert archive_path.stat().st_size==package['bytes'],'Unexpected download size'
    assert digest.hexdigest()==package['checksum'],'Download checksum mismatch'
    if package['package']=='ecj':
        if archive_path!=compiler:shutil.move(archive_path,compiler)
        return
    target=platform.parent if package['package'].startswith('platforms') else tools
    target.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive_path) as archive:
        for entry in archive.infolist():
            parts=Path(entry.filename).parts[1:]
            if not parts:continue
            assert '..' not in parts
            destination=target.joinpath(*parts)
            if entry.is_dir():
                destination.mkdir(parents=True,exist_ok=True);continue
            destination.parent.mkdir(parents=True,exist_ok=True)
            destination.write_bytes(archive.read(entry))
            mode=(entry.external_attr>>16)&0o777
            destination.chmod(mode or 0o644)
    if target==tools:
        for name in ('aapt2','d8','apksigner','zipalign'):(tools/name).chmod(0o755)

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    list(pool.map(acquire,lock))

def run(*command):
    result=subprocess.run([str(item) for item in command],check=False,text=True,
        stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(result.stdout)
    return result.stdout

for dependency in json.loads((PROJECT/'dependencies-lock.json').read_text()):
    file=PROJECT/'libs'/dependency['file']
    assert hashlib.sha256(file.read_bytes()).hexdigest()==dependency['sha256'], 'Dependency checksum mismatch: '+file.name

work=PROJECT/'build'
work.mkdir(exist_ok=True)
classes=work/'classes'
dex=work/'dex'
shutil.rmtree(classes,ignore_errors=True)
shutil.rmtree(dex,ignore_errors=True)
classes.mkdir(exist_ok=True)
dex.mkdir(exist_ok=True)
sources=sorted((PROJECT/'app/src/main/java').rglob('*.java'))
compile_log=run('java','-jar',compiler,'-8','-proc:none','-encoding','UTF-8',
    '-bootclasspath',str(platform)+':'+str(tools/'core-lambda-stubs.jar'),'-classpath',':'.join(str(p) for p in (PROJECT/'libs').glob('*.jar')),'-d',classes,*sources)
class_files=sorted(classes.rglob('*.class'))
assert class_files
run(tools/'d8','--lib',platform,'--min-api','26','--output',dex,*class_files,*sorted((PROJECT/'libs').glob('*.jar')))
resources=work/'resources.zip'
base=work/'resources.apk'
run(tools/'aapt2','compile','--dir',PROJECT/'app/src/main/res','-o',resources)
run(tools/'aapt2','link','-I',platform,'--manifest',PROJECT/'app/src/main/AndroidManifest.xml',
    '-A',PROJECT/'app/src/main/assets','-o',base,resources)
unsigned=work/'unsigned.apk'
shutil.copy2(base,unsigned)
with zipfile.ZipFile(unsigned,'a',compression=zipfile.ZIP_DEFLATED) as archive:
    for dex_file in sorted(dex.glob('*.dex')):
        archive.write(dex_file,dex_file.name)
aligned=work/'aligned.apk'
run(tools/'zipalign','-f','-P','16','4',unsigned,aligned)
signing=PROJECT/'signing'
signing.mkdir(exist_ok=True)
key=signing/'starlights-atlas.p12'
if not key.exists():
    run('keytool','-genkeypair','-keystore',key,'-storetype','PKCS12',
        '-storepass','android','-keypass','android','-alias','starlight',
        '-dname','CN=Nova Sky, OU=Private App, O=David and Nova',
        '-keyalg','RSA','-keysize','2048','-validity','10000','-noprompt')
run(tools/'apksigner','sign','--ks',key,'--ks-pass','pass:android',
    '--key-pass','pass:android','--ks-key-alias','starlight',
    '--out',output,aligned)
signature=run(tools/'apksigner','verify','--verbose','--print-certs',output)
run(tools/'zipalign','-c','-P','16','4',output)
badging=run(tools/'aapt2','dump','badging',output)
assert "package: name='com.novasky.atlas'" in badging
assert "minSdkVersion:'26'" in badging
assert "targetSdkVersion:'35'" in badging
assert "launchable-activity: name='com.novasky.atlas.MainActivity'" in badging
assert 'android.permission.INTERNET' not in badging
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    assert archive.read('classes.dex').startswith(b'dex\n')
    assert {'AndroidManifest.xml','resources.arsc','classes.dex','assets/about.txt'}<=set(archive.namelist())

report={
    'apk':output.name,'bytes':output.stat().st_size,
    'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
    'min_android_api':26,'target_android_api':35,
    'signature_verified':True,'zip_alignment_verified':True,
    'internet_permission':False,'native_shell_local_web_ui':True,
    'device_runtime_tested':False,
    'signature_report':signature,'package_report':badging,
}
(work/'verification.json').write_text(json.dumps(report,indent=2))
print('Compiled, packaged, aligned, signed, and verified:',output)
print('APK bytes:',report['bytes'])
print('Internet permission: none. Offline lore encyclopedia: included.')
print(signature)
