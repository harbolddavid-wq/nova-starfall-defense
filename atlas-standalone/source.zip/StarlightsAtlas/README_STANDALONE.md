# Starlight’s Atlas · Standalone 1.0

For Desi’s Samsung Galaxy A17 5G. An offline RP character and universe reference library.

## Included
- Characters and custom profile fields, photos, mini designs, accessories, and extra image slots
- Species encyclopedia, interconnected relationships, power hierarchies
- Worlds, alternate character versions, timeline and future events
- Locations, items, notebook, global search, bookmarks and recoverable Trash
- Offline on-device auto-save; manual `.atlas` export and restore of lore and photo copies

## No other apps required
All Dream / Studio integration menus, scripts, package queries, handoff receivers, and share provider code have been removed. Import photographs directly using Android’s file picker. No network permission, login, ads or subscription.

## Install / backup
Same package ID (`com.novasky.atlas`) and update key as the previous release. Version code 4, higher than the v0.2.1 build. If installing on an older device, export an Atlas backup *before* any uninstall or data clear. The new phone will start with an empty local library unless an exported `.atlas` backup is imported. Installing on a different phone does not automatically recover data.

Image copies are optimized to 2048 px maximum long edge; original image files on the phone remain untouched. Keep backup files outside the app. Device testing is still required after installation.
