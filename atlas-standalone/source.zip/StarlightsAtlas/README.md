# Starlight’s Atlas
Offline Android lore encyclopedia, version 0.1.0, package `com.novasky.atlas`.

The native Java shell serves bundled HTML/CSS/JavaScript over an intercepted local HTTPS origin. The app has no Internet permission. IndexedDB stores structured references and image blobs separately. UUID links preserve identity; world variants inherit base fields with explicit overrides. Data-driven shelves support characters, variants, species, worlds, nested power categories, events, and notes.

The Java bridge provides clipboard and chunked local backup export. Backup JSON escapes Unicode before chunking to avoid splitting UTF-16 surrogate pairs during UTF-8 encoding. Downloads uses MediaStore pending writes; a document picker is available as an alternative. Reference images are downsampled to a 2048-pixel long edge. Imports validate their structure and atomically replace the library and image records, keeping a pre-import library copy. Imported image IDs are remapped to protect that recovery copy.

## Build
Use `python3 build.py --toolchain /path/to/android-build`. Toolchain versions and checksums are locked. Java compilation uses ECJ with Android API 35; minimum Android API 26. Output is `../Starlights_Atlas.apk`.

Signing material is intentionally excluded from the source archive. Without the original update key, the builder generates a different key; that APK cannot update an existing installation. Preserve the original signing key privately for future updates.

## Checks
`node tests/model.cjs` executes 13 model regression checks.
`node --check app/src/main/assets/app.js` verifies JavaScript syntax.
`node tests/check.cjs` is the broader Playwright suite. It requires Playwright and a working headless Chromium; adjust its executable path for your machine. It did not execute in the build environment, so there are no claimed browser/UI passes.

See START_HERE.md and qa/validation.json for the verification limits. Browser model testing does not verify Android WebView, content URIs, image picking, MediaStore, or activity lifecycle behavior.

## 0.2.0 integration
Both apps now exchange explicit PNG copies and local project links. See START_HERE.md for actions, ownership rules, backup/link limits and phone validation. Integration code is in DreamIntegration.java / AtlasIntegration.java and Atlas assets integration.js and handoff.js. Source backups exclude private signing keys and build tools.
