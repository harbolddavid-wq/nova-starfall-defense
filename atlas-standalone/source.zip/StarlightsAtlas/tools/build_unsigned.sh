#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/opt/android-sdk}}"
BT="$SDK/build-tools/35.0.0"
PLATFORM="$SDK/platforms/android-35/android.jar"
WORK="$(pwd)/build-standalone"
mkdir -p "$WORK/classes" "$WORK/dex" "$WORK/output"
find app/src/main/java -name '*.java' -print > "$WORK/java-files.txt"
javac -source 8 -target 8 -encoding UTF-8 -Xlint:-options -bootclasspath "$PLATFORM" -d "$WORK/classes" @"$WORK/java-files.txt"
find "$WORK/classes" -name '*.class' -print > "$WORK/class-files.txt"
"$BT/d8" --lib "$PLATFORM" --min-api 26 --output "$WORK/dex" $(cat "$WORK/class-files.txt")
"$BT/aapt2" compile --dir app/src/main/res -o "$WORK/resources.zip"
"$BT/aapt2" link -I "$PLATFORM" --manifest app/src/main/AndroidManifest.xml -A app/src/main/assets -o "$WORK/base.apk" "$WORK/resources.zip"
python3 - "$WORK/base.apk" "$WORK/dex" "$WORK/unsigned-unaligned.apk" <<'PY'
import shutil,sys,zipfile,pathlib
base=pathlib.Path(sys.argv[1]);dex=pathlib.Path(sys.argv[2]);dest=pathlib.Path(sys.argv[3]);shutil.copyfile(base,dest)
with zipfile.ZipFile(dest,'a',compression=zipfile.ZIP_DEFLATED) as out:
 for file in sorted(dex.glob('*.dex')):out.write(file,file.name)
PY
"$BT/zipalign" -f -P 16 4 "$WORK/unsigned-unaligned.apk" "$WORK/output/Starlights_Atlas_Standalone_1.0_unsigned.apk"
"$BT/zipalign" -c -P 16 4 "$WORK/output/Starlights_Atlas_Standalone_1.0_unsigned.apk"
"$BT/aapt2" dump badging "$WORK/output/Starlights_Atlas_Standalone_1.0_unsigned.apk" | tee "$WORK/output/badging.txt"
python3 - "$WORK/output/Starlights_Atlas_Standalone_1.0_unsigned.apk" <<'PY'
import zipfile,sys
with zipfile.ZipFile(sys.argv[1]) as z:
 assert z.testzip() is None
 assert z.read('classes.dex').startswith(b'dex\n')
 assert 'assets/app.js' in z.namelist()
 assert 'assets/integration.js' not in z.namelist()
 assert 'assets/handoff.js' not in z.namelist()
 assert 'classes.dex' in z.namelist()
print('Verified: standalone APK content and dex present')
PY
cp "$BT/lib/apksigner.jar" "$WORK/output/apksigner.jar"
echo 'Unsigned release built successfully.'
