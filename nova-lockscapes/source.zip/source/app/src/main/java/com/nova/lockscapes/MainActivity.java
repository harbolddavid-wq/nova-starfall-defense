package com.nova.lockscapes;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public final class MainActivity extends Activity {
  static final int BG=0xff100c1b, PANEL=0xff2b203d, LILAC=0xffd4b5ff, WHITE=0xfffff1fc, ORANGE=0xffffad68;
  static final int OPEN_IMAGE=20, OPEN_PACK=21;
  SharedPreferences prefs; LinearLayout root, body; Preview preview;
  String chosen="built:0";
  int dp(float px){return (int)(getResources().getDisplayMetrics().density*px+.5f);}
  void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  TextView label(String text,int size){TextView v=new TextView(this);v.setText(text);v.setTextSize(size);v.setTextColor(WHITE);v.setPadding(dp(5),dp(6),dp(5),dp(6));return v;}
  LinearLayout vert(){LinearLayout c=new LinearLayout(this);c.setOrientation(1);return c;}
  void add(LinearLayout p,View v){p.addView(v,new LinearLayout.LayoutParams(-1,-2));}
  Button button(String text,Runnable tap){Button b=new Button(this);b.setAllCaps(false);b.setText(text);b.setTextColor(WHITE);b.setTextSize(14);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PANEL));b.setOnClickListener(v->tap.run());return b;}
  @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("lockscapes",MODE_PRIVATE);chosen=prefs.getString("scene","built:0");home();}
  void screen(String title,String subtitle){
    if(preview!=null){preview.stop();preview=null;}
    root=vert();root.setBackgroundColor(BG);setContentView(root);
    TextView head=label("✦ "+title,23);head.setTextColor(ORANGE);head.setTypeface(null,1);head.setPadding(dp(15),dp(18),dp(15),dp(4));add(root,head);
    TextView sub=label(subtitle,13);sub.setPadding(dp(15),0,dp(15),dp(9));add(root,sub);
    ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    body=vert();body.setPadding(dp(11),dp(4),dp(11),dp(30));scroll.addView(body);
  }
  void home(){screen("NOVA LOCKSCAPES","Quality-first wallpapers for your BLU. No ads, accounts or tracking.");
    TextView info=label("1 HD world + 23 classic scenes   •   Full-quality imports   •   Layered scene packs",15);info.setTextColor(LILAC);add(body,info);
    add(body,button("✦ Preview my selected world",()->openScene(chosen)));
    add(body,button("＋ Import a picture (PNG, JPG, WEBP)",()->pick(OPEN_IMAGE,"image/*")));
    add(body,button("＋ Import Nova Scene Pack (ZIP)",()->pick(OPEN_PACK,"application/zip")));
    add(body,label("Choose a built-in world",19));
    GridLayout grid=new GridLayout(this);grid.setColumnCount(3);add(body,grid);
    int cell=(getResources().getDisplayMetrics().widthPixels-dp(43))/3;
    for(int i=0;i<Worlds.NAMES.length;i++){
      int index=i;String key="built:"+i;
      LinearLayout tile=vert();tile.setBackgroundColor(PANEL);tile.setPadding(dp(3),dp(4),dp(3),dp(4));
      ImageView thumb=new ImageView(this);thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
      Bitmap bitmap=Worlds.sample(this,key,130,195);thumb.setImageBitmap(bitmap);
      tile.addView(thumb,new LinearLayout.LayoutParams(-1,dp(135)));
      TextView title=label(Worlds.NAMES[i],11);title.setGravity(Gravity.CENTER);title.setMaxLines(2);tile.addView(title,new LinearLayout.LayoutParams(-1,dp(44)));
      GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=cell;gp.height=dp(187);gp.setMargins(dp(2),dp(2),dp(2),dp(2));grid.addView(tile,gp);
      tile.setOnClickListener(v->openScene(key));
    }
    add(body,label("Your imported worlds",19));
    File imports=new File(getFilesDir(),"imports");File[] images=imports.listFiles();
    if(images!=null){Arrays.sort(images);for(File f:images){if(!f.isFile()||!f.getName().matches("(?i).+\\.(jpg|jpeg|png|webp)"))continue;
      String key="image:"+f.getName();add(body,button("◈ "+displayName(f.getName())+"  ›",()->openScene(key)));}}
    File packs=new File(getFilesDir(),"packs");File[] folders=packs.listFiles();
    if(folders!=null){Arrays.sort(folders);for(File f:folders){if(!f.isDirectory())continue;
      String key="pack:"+f.getName();add(body,button("✧ "+displayName(f.getName())+" [2.5D]  ›",()->openScene(key)));}}
    add(body,label("Lock screen safety: this changes wallpaper artwork, never your PIN, fingerprint, clock or notifications. Live wallpaper placement depends on your phone's Android wallpaper picker.",12));
  }
  String displayName(String filename){return filename.replaceFirst("(?i)\\.(jpg|jpeg|png|webp)$","").replace('_',' ').replace('-',' ');}
  void pick(int request,String type){try{Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(type);if(request==OPEN_PACK)intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/zip","application/x-zip-compressed","application/octet-stream"});startActivityForResult(intent,request);}catch(Exception ex){toast("Could not open file picker: "+ex.getMessage());}}
  void openScene(String key){chosen=key;prefs.edit().putString("scene",key).apply();
    String name="Your world";
    if(key.startsWith("built:")){try{name=Worlds.NAMES[Integer.parseInt(key.substring(6))];}catch(Exception ignored){}}
    else if(key.startsWith("image:"))name=displayName(key.substring(6));
    else if(key.startsWith("pack:"))name=displayName(key.substring(5));
    screen(name,"Original-quality artwork, adjustable fit and gentle optional movement.");
    add(body,button("← Back to all worlds",this::home));
    preview=new Preview(key);add(body,preview);preview.getLayoutParams().height=dp(410);
    if(key.startsWith("image:")||key.startsWith("pack:")||key.equals("built:0")){
      final String[] modes={"Fill screen (crop edges)","Fit entire image (no crop)","Custom crop and position"};
      int current=prefs.getInt("fitMode",0);
      if(current<0||current>2)current=0;
      android.widget.Spinner sizing=new android.widget.Spinner(this);
      android.widget.ArrayAdapter<String> options=new android.widget.ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,modes);
      sizing.setAdapter(options);sizing.setSelection(current);
      add(body,label("Image framing",17));add(body,sizing);
      sizing.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
        public void onNothingSelected(android.widget.AdapterView<?> p){}
        public void onItemSelected(android.widget.AdapterView<?> p,View v,int i,long id){prefs.edit().putInt("fitMode",i).apply();preview.invalidate();}
      });
      add(body,label("Zoom",14));SeekBar zoom=new SeekBar(this);zoom.setMax(150);zoom.setProgress(prefs.getInt("zoom",0));add(body,zoom);
      zoom.setOnSeekBarChangeListener(seek("zoom"));
      add(body,label("Horizontal position",14));SeekBar panX=new SeekBar(this);panX.setMax(200);panX.setProgress(prefs.getInt("panX",100));add(body,panX);
      panX.setOnSeekBarChangeListener(seek("panX"));
      add(body,label("Vertical position",14));SeekBar panY=new SeekBar(this);panY.setMax(200);panY.setProgress(prefs.getInt("panY",100));add(body,panY);
      panY.setOnSeekBarChangeListener(seek("panY"));
      TextView pixels=label("Imported images are kept in their original format. Portrait fill can crop wide images; Fit keeps every part visible.",12);
      pixels.setTextColor(LILAC);add(body,pixels);
      add(body,button("Reset crop and position",()->{prefs.edit().putInt("zoom",0).putInt("panX",100).putInt("panY",100).putInt("fitMode",0).apply();openScene(key);}));
    }
    add(body,label("Motion strength",15));
    SeekBar strength=new SeekBar(this);strength.setMax(100);strength.setProgress(prefs.getInt("motion",55));add(body,strength);
    strength.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}
      public void onProgressChanged(SeekBar s,int progress,boolean from){if(from)prefs.edit().putInt("motion",progress).apply();}});
    CheckBox particles=new CheckBox(this);particles.setText("Glowing dust, stars and particles");particles.setTextColor(WHITE);particles.setChecked(prefs.getBoolean("particles",true));add(body,particles);
    particles.setOnCheckedChangeListener((v,checked)->prefs.edit().putBoolean("particles",checked).apply());
    CheckBox tilt=new CheckBox(this);tilt.setText("Tilt-motion effect (uses accelerometer)");tilt.setTextColor(WHITE);tilt.setChecked(prefs.getBoolean("tilt",true));add(body,tilt);
    tilt.setOnCheckedChangeListener((v,checked)->prefs.edit().putBoolean("tilt",checked).apply());
    add(body,button("✦ USE ANIMATED LIVE WALLPAPER",this::applyLive));
    add(body,label("Android will show its own preview and installation choices. Some phones do not offer 'Lock only' for animated wallpapers.",12));
    add(body,button("▧ SET STATIC LOCK SCREEN ONLY",()->applyStatic(WallpaperManager.FLAG_LOCK)));
    add(body,button("▧ Set static Home only",()->applyStatic(WallpaperManager.FLAG_SYSTEM)));
    add(body,button("▧ Set static Home + Lock",()->applyStatic(WallpaperManager.FLAG_LOCK|WallpaperManager.FLAG_SYSTEM)));
    if(!key.startsWith("built:"))add(body,button("× Delete this imported world",()->confirmDelete(key)));
  }
  SeekBar.OnSeekBarChangeListener seek(String name){return new SeekBar.OnSeekBarChangeListener(){
    public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}
    public void onProgressChanged(SeekBar s,int progress,boolean from){if(from){prefs.edit().putInt(name,progress).apply();if(preview!=null)preview.invalidate();}}
  };}
  void applyLive(){prefs.edit().putString("scene",chosen).apply();try{
      Intent intent=new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
      intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,new ComponentName(this,LockscapeWallpaperService.class));
      startActivity(intent);
    }catch(Exception e){toast("This device could not open the live wallpaper picker: "+e.getMessage());}}
  void applyStatic(int flags){
    try{
      int width=Math.max(720,getResources().getDisplayMetrics().widthPixels);
      int height=Math.max(1280,getResources().getDisplayMetrics().heightPixels);
      // Render at the actual device resolution; never impose the old 1600-pixel cap.
      // A 4096px safeguard protects low-RAM devices with exotic external displays.
      float scale=Math.min(1f,4096f/Math.max(width,height));width=(int)(width*scale);height=(int)(height*scale);
      Bitmap wallpaper=Worlds.sample(this,chosen,width,height,prefs.getInt("fitMode",0),prefs.getInt("zoom",0),prefs.getInt("panX",100),prefs.getInt("panY",100));
      try{WallpaperManager manager=WallpaperManager.getInstance(this);manager.setBitmap(wallpaper,null,false,flags);}finally{wallpaper.recycle();}
      toast(flags==WallpaperManager.FLAG_LOCK?"Static LOCK wallpaper applied!":"Static wallpaper applied!");
    }catch(Exception ex){new AlertDialog.Builder(this).setTitle("Could not set wallpaper").setMessage(ex.getClass().getSimpleName()+": "+ex.getMessage()).setPositiveButton("OK",null).show();}
  }
  void confirmDelete(String key){new AlertDialog.Builder(this).setTitle("Delete imported world?").setMessage("Deletes the saved copy inside Nova Lockscapes, not the original photo on your phone.")
      .setPositiveButton("Delete",(d,w)->{try{
         File f;if(key.startsWith("image:"))f=new File(new File(getFilesDir(),"imports"),key.substring(6));
         else f=new File(new File(getFilesDir(),"packs"),key.substring(5));remove(f);
         prefs.edit().putString("scene","built:0").apply();chosen="built:0";home();
      }catch(Exception ex){toast("Could not delete: "+ex.getMessage());}}).setNegativeButton("Cancel",null).show();}
  static void remove(File f){if(f.isDirectory()){File[] children=f.listFiles();if(children!=null)for(File c:children)remove(c);}f.delete();}

  @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
    if(result!=RESULT_OK||data==null||data.getData()==null)return;
    try{String newScene=request==OPEN_IMAGE?importImage(data.getData()):importPack(data.getData());openScene(newScene);
    }catch(Exception e){new AlertDialog.Builder(this).setTitle("Could not import").setMessage(e.getMessage()==null?e.toString():e.getMessage()).setPositiveButton("OK",null).show();}
  }
  static String newId(){return "nova_"+Long.toString(System.currentTimeMillis(),36)+"_"+Integer.toString((int)(Math.random()*100000),36);}
  // Import is BYTE FOR BYTE. Never convert PNG/WEBP to JPEG or downscale the saved master.
  String importImage(Uri uri) throws Exception {
    File folder=new File(getFilesDir(),"imports");
    if(!folder.exists()&&!folder.mkdirs())throw new Exception("Cannot create imports folder");
    byte[] buf=new byte[32768];byte[] header=new byte[12];
    try(InputStream stream=getContentResolver().openInputStream(uri)){
      if(stream==null)throw new Exception("Cannot open source image");
      int received=0;while(received<header.length){int n=stream.read(header,received,header.length-received);if(n<0)break;received+=n;}
      String ext;
      if(received>=8 && (header[0]&255)==137 && header[1]==80 && header[2]==78 && header[3]==71)ext="png";
      else if(received>=3 && (header[0]&255)==255 && (header[1]&255)==216 && (header[2]&255)==255)ext="jpg";
      else if(received>=12 && header[0]=='R'&&header[1]=='I'&&header[2]=='F'&&header[3]=='F'&&header[8]=='W'&&header[9]=='E'&&header[10]=='B'&&header[11]=='P')ext="webp";
      else throw new Exception("Choose a PNG, JPEG or WebP image.");
      File dest=new File(folder,newId()+"."+ext);
      try{
        long size=received;
        try(OutputStream out=new FileOutputStream(dest)){
          out.write(header,0,received);int count;
          while((count=stream.read(buf))>=0){size+=count;
            if(size>60L*1024*1024)throw new Exception("Image is over the 60 MB limit.");
            out.write(buf,0,count);
          }
        }
        BitmapFactory.Options dimensions=new BitmapFactory.Options();dimensions.inJustDecodeBounds=true;
        BitmapFactory.decodeFile(dest.getAbsolutePath(),dimensions);
        if(dimensions.outWidth<1||dimensions.outHeight<1||dimensions.outWidth>30000||dimensions.outHeight>30000||
          ((long)dimensions.outWidth)*dimensions.outHeight>150000000L)throw new Exception("Image has invalid or unsupported dimensions.");
        return "image:"+dest.getName();
      }catch(Exception ex){dest.delete();throw ex;}
    }
  }
  String importPack(Uri uri) throws Exception {
    File parent=new File(getFilesDir(),"packs");if(!parent.exists()&&!parent.mkdirs())throw new Exception("Cannot create packs directory");
    String id=newId();File folder=new File(parent,id);if(!folder.mkdir())throw new Exception("Cannot create this scene folder");
    int total=0,entries=0;boolean found=false;
    try(InputStream source=getContentResolver().openInputStream(uri)){
      if(source==null)throw new Exception("Cannot open scene ZIP");
      try(ZipInputStream zip=new ZipInputStream(source)){
        ZipEntry entry;byte[] buffer=new byte[8192];
        while((entry=zip.getNextEntry())!=null){
          entries++;if(entries>30)throw new Exception("Scene pack has too many files");
          String name=entry.getName();if(entry.isDirectory()){zip.closeEntry();continue;}
          boolean accepted=name.equals("background.png")||name.equals("background.jpg")||name.equals("background.webp")||name.equals("foreground.png")||name.equals("foreground.webp")||name.equals("name.txt");
          if(!accepted){zip.closeEntry();continue;}
          if(name.startsWith("background."))found=true;
          try(OutputStream output=new FileOutputStream(new File(folder,name))){int len,fileBytes=0;
            while((len=zip.read(buffer))!=-1){fileBytes+=len;total+=len;
              if(fileBytes>14*1024*1024||total>28*1024*1024)throw new Exception("Scene pack is too large (limit 28 MB)");
              output.write(buffer,0,len);
            }}zip.closeEntry();
        }
      }
      if(!found)throw new Exception("ZIP needs background.png (or background.jpg/background.webp). Optional foreground.png adds a second depth layer.");
      Worlds.SceneArt check=Worlds.SceneArt.load(this,"pack:"+id,1080,2400);
      boolean valid=check.background!=null;check.clear();if(!valid)throw new Exception("Scene background was not a valid image");
      return "pack:"+id;
    }catch(Exception ex){remove(folder);throw ex;}
  }

  class Preview extends View {
    final String key;final Worlds.SceneArt art;final Handler handler=new Handler(Looper.getMainLooper());long first=android.os.SystemClock.uptimeMillis();boolean running=true;
    Runnable tick=new Runnable(){@Override public void run(){if(!running)return;invalidate();handler.postDelayed(this,44);}};
    Preview(String key){super(MainActivity.this);this.key=key;this.art=Worlds.SceneArt.load(MainActivity.this,key,1080,2400);
      setBackgroundColor(0xff1b122a);handler.postDelayed(tick,50);}
    @Override public void onDraw(Canvas c){super.onDraw(c);float seconds=(android.os.SystemClock.uptimeMillis()-first)/1000f;
      Worlds.draw(c,getWidth(),getHeight(),key,art,seconds,prefs.getInt("motion",55)/100f,0,0,prefs.getBoolean("particles",true),prefs.getInt("fitMode",0),prefs.getInt("zoom",0),prefs.getInt("panX",100),prefs.getInt("panY",100));}
    void stop(){running=false;handler.removeCallbacks(tick);art.clear();}
    @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}
  }
}
