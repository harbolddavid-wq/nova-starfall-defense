package com.nova.lockscapes;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import java.io.File;
import java.util.Random;

/** Twenty-four original procedural scenes + imported artwork with optional two-layer depth. */
public final class Worlds {
  public static final String[] NAMES = {
    "Inferno Gate · HD", "Violet Nebula", "Crystal Lake", "Gothic Cathedral",
    "Emerald Forest", "Falling Snow", "Neon Orbit", "Ember Dragon",
    "Haunted Clock", "Dream Moths", "Moonlit Harbor", "Ancient Library",
    "Dark Roses", "Storm Keep", "Astral Stairway", "Crimson Eclipse",
    "Underwater Ruins", "Solar Flare", "Starfall", "Twilight Desert",
    "Phantom Garden", "Circuit City", "Whispering Fog", "Rainbow Rift"
  };
  static final int[] SKY_TOP={
    0xff120812,0xff100c38,0xff081729,0xff130b27,0xff031e16,0xff162b3c,
    0xff130c32,0xff240a12,0xff080a1c,0xff1a1237,0xff0b1530,0xff1d1127,
    0xff210d25,0xff0b1325,0xff120f2f,0xff330a12,0xff06243a,0xff2e1421,
    0xff030927,0xff221338,0xff0b1b19,0xff101227,0xff181b2b,0xff201339
  };
  static final int[] SKY_BOTTOM={
    0xff622018,0xff4b2682,0xff1c6c89,0xff4e315b,0xff135742,0xff5485a8,
    0xff4639a7,0xffb34124,0xff393551,0xff744c92,0xff2e7798,0xff66485f,
    0xff88435f,0xff4e566b,0xff534eac,0xffab2839,0xff166d89,0xffce7d32,
    0xff323c9b,0xffb07872,0xff315b65,0xff6430a3,0xff667783,0xffad56a4
  };
  static final int[] GLOW={
    0xffff9044,0xffdf8fff,0xff88efff,0xffc896ff,0xff80efb2,0xffe7f8ff,
    0xfffa7ff9,0xffffc578,0xffd8c3ff,0xffefc4ff,0xffbedaff,0xffffd39d,
    0xffff9abb,0xfff0bbff,0xffd1bfff,0xffff938a,0xff95eeff,0xffffd581,
    0xffcddaff,0xffffdcaf,0xffb6ffdc,0xfff198ff,0xffd7edff,0xffffccfb
  };
  private Worlds() {}

  public static Bitmap sample(Context context, String key, int w, int h) {
    return sample(context,key,w,h,0,0,100,100);
  }

  public static Bitmap sample(Context context, String key, int w, int h,int fitMode,int zoom,int panX,int panY) {
    Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
    SceneArt art=SceneArt.load(context,key,w,h);
    try {draw(new Canvas(b),w,h,key,art,0f,0f,0f,0f,key.startsWith("built:")&&art.background==null,fitMode,zoom,panX,panY);}
    finally {art.clear();}
    return b;
  }

  // Keep original signature available for callers still using classic defaults.
  public static void draw(Canvas canvas,int width,int height,String key,SceneArt asset,
                          float clock,float strength,float tiltX,float tiltY,boolean particles){
    draw(canvas,width,height,key,asset,clock,strength,tiltX,tiltY,particles,0,0,100,100);
  }

  public static void draw(Canvas canvas,int width,int height,String key,SceneArt asset,
                          float clock,float strength,float tiltX,float tiltY,boolean particles,
                          int fitMode,int zoom,int panX,int panY) {
    if(width<=0||height<=0)return;
    if(key!=null&&key.startsWith("built:")&&(asset==null||asset.background==null)) {
      int n=0;try{n=Integer.parseInt(key.substring(6));}catch(Exception ignored){}
      procedural(canvas,width,height,Math.max(0,Math.min(NAMES.length-1,n)),clock,strength,tiltX,tiltY,particles);
    } else if(asset!=null&&asset.background!=null) {
      canvas.drawColor(0xff110c20);
      float parallaxX=(float)Math.sin(clock*.15f)*6*strength+tiltX*9*strength;
      float parallaxY=(float)Math.cos(clock*.12f)*5*strength+tiltY*7*strength;
      // The same positioning is used for STATIC and LIVE wallpaper; no automatic 9% overscan.
      drawFramed(canvas,asset.background,width,height,fitMode,zoom,panX,panY,parallaxX,parallaxY);
      if(asset.foreground!=null)drawFramed(canvas,asset.foreground,width,height,fitMode,zoom,panX,panY,parallaxX*1.8f,parallaxY*1.8f);
      if(particles&&strength>0)drawParticleOverlay(canvas,width,height,clock,strength,0xffd9b9ff,asset.foreground!=null?18:12);
      // Deliberately no vignette or translucent color filter on an imported photograph.
    } else {
      canvas.drawColor(0xff19142c);
    }
  }

  public static void drawFramed(Canvas c,Bitmap b,int w,int h,int fitMode,int zoom,int panX,int panY,float dx,float dy){
    if(b==null||b.isRecycled())return;
    // Mode 0 is centered Fill; 1 is whole-image Fit; 2 is adjustable Custom Crop.
    float base=fitMode==1?Math.min(w/(float)b.getWidth(),h/(float)b.getHeight()):Math.max(w/(float)b.getWidth(),h/(float)b.getHeight());
    float factor=base*(fitMode==2?(1f+Math.max(0,Math.min(150,zoom))/100f):1f);
    float bw=b.getWidth()*factor,bh=b.getHeight()*factor;
    float extraX=Math.max(0f,bw-w),extraY=Math.max(0f,bh-h);
    float x=(w-bw)*.5f - (fitMode==2?(Math.max(0,Math.min(200,panX))-100)/100f*extraX*.5f:0);
    float y=(h-bh)*.5f - (fitMode==2?(Math.max(0,Math.min(200,panY))-100)/100f*extraY*.5f:0);
    // Motion stays inside available overscan; static artwork draws at its true framing.
    if(extraX>0)x+=Math.max(-extraX*.5f,Math.min(extraX*.5f,dx));
    if(extraY>0)y+=Math.max(-extraY*.5f,Math.min(extraY*.5f,dy));
    if(extraX>0)x=Math.max(w-bw,Math.min(0,x));
    if(extraY>0)y=Math.max(h-bh,Math.min(0,y));
    Paint p=new Paint(Paint.FILTER_BITMAP_FLAG|Paint.ANTI_ALIAS_FLAG|Paint.DITHER_FLAG);
    c.drawBitmap(b,null,new RectF(x,y,x+bw,y+bh),p);
  }

  static Paint p(int c){Paint p=new Paint(3);p.setColor(c);return p;}
  static void disk(Canvas c,float x,float y,float r,int col){c.drawCircle(x,y,r,p(col));}
  static void line(Canvas c,float x,float y,float X,float Y,int col,float thick){Paint p=p(col);p.setStrokeWidth(thick);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(x,y,X,Y,p);}
  static void tri(Canvas c,int color,float...xy){Path q=new Path();q.moveTo(xy[0],xy[1]);for(int i=2;i<xy.length;i+=2)q.lineTo(xy[i],xy[i+1]);q.close();c.drawPath(q,p(color));}
  static void poly(Canvas c,int color,float...xy){Path q=new Path();q.moveTo(xy[0],xy[1]);for(int i=2;i<xy.length;i+=2)q.lineTo(xy[i],xy[i+1]);q.close();c.drawPath(q,p(color));}
  static void drawParticleOverlay(Canvas c,int w,int h,float t,float str,int color,int count){
    Random r=new Random(992321L+count);Paint p=p(color);
    for(int i=0;i<count;i++){
      float x=r.nextFloat()*w,y=(r.nextFloat()*h+(float)Math.sin(t*.4+i)*14*str+h)%h;
      p.setAlpha(70+r.nextInt(130)); c.drawCircle(x,y,1.2f+r.nextFloat()*2.5f,p);
    }
  }
  static void vignette(Canvas c,int w,int h){
    Paint v=p(0);v.setShader(new android.graphics.RadialGradient(w/2f,h*.45f,Math.max(w,h)*.79f,
      new int[]{0x000a0615,0x030a0615,0x88070513},new float[]{0,.53f,1},Shader.TileMode.CLAMP));
    c.drawRect(0,0,w,h,v);
  }

  static void procedural(Canvas original,int W,int H,int index,float t,float move,float tiltX,float tiltY,boolean particles){
    original.save();original.scale(W/360f,H/780f);Canvas c=original;
    int n=index, top=SKY_TOP[n], bottom=SKY_BOTTOM[n], light=GLOW[n];
    Paint bg=p(top);bg.setShader(new LinearGradient(0,0,0,780,top,bottom,Shader.TileMode.CLAMP));c.drawRect(0,0,360,780,bg);
    // Stars are painted above geometry so every scene remains distinct even while still.
    Random r=new Random(5147+n*239L);
    Paint star=p(0xffffffff);
    for(int i=0;i<85;i++){float x=r.nextFloat()*360,y=r.nextFloat()*690,rad=.4f+r.nextFloat()*1.7f;
      star.setAlpha(50+r.nextInt(155));c.drawCircle(x,y,rad,star);}
    float breathing=(float)Math.sin(t*.19f)*7*move;
    float sway=(float)Math.sin(t*.13f)*9*move+tiltX*6*move;
    // Distant luminous object, horizon glow.
    Paint halo=p(light);halo.setAlpha(60);disk(c,240+sway*.3f,205+breathing,85,0x2244ffff);
    disk(c,252+sway*.3f,205+breathing,53,light);
    disk(c,265+sway*.3f,194+breathing,48,top);
    switch(n%8){
      case 0: // castle gate over lava lake
        mountain(c,0xff211526,100+sway*.2f,515,145,360);mountain(c,0xff331b35,250-sway*.2f,560,180,320);
        c.drawRect(0,587,360,780,p(0xff120c1b));
        for(int i=0;i<18;i++){float y=602+i*12;c.drawRect(0,y,360,y+2,p(i%2==0?light:0xff813326));}
        castle(c,180+sway*.5f,548,light);
        break;
      case 1: // galactic rings and orbit
        Paint orbit=p(light);orbit.setStyle(Paint.Style.STROKE);orbit.setStrokeWidth(6);
        c.save();c.rotate(-24+sway*.3f,178,395);c.drawOval(22,270,338,510,orbit);c.restore();
        disk(c,180+sway,400+breathing,76,light);disk(c,196+sway,385+breathing,67,bottom);
        for(int i=0;i<14;i++){float x=i*28;line(c,x,690,x+40,770,0x445defff,2);}
        break;
      case 2: // reflective crystalline waters
        mountain(c,0xff0b263e,100,520,120,260);mountain(c,0xff0d3141,240,560,160,220);
        c.drawRect(0,562,360,780,p(0xff082a43));
        for(int i=0;i<25;i++){float y=570+i*8f;line(c,180-(i%8)*17,y,180+(i%8)*17,y,light,2);}
        for(int i=0;i<6;i++){float x=i*58+14;poly(c,0xff88ccff,x,568,x+15,468-i*7,x+26,568);}
        break;
      case 3: // cathedral silhouettes with glowing window
        c.drawRect(0,480,360,780,p(0xff100d1d));
        for(int i=0;i<3;i++){float x=29+i*124;poly(c,0xff1a1429,x,650,x,338,x+48,275,x+96,338,x+96,650);
          disk(c,x+48,391,26,light);disk(c,x+48,391,20,0xff251338);
          line(c,x+48,369,x+48,414,light,3);line(c,x+26,391,x+70,391,light,3);
        }break;
      case 4: // forest of luminous trunks
        mountain(c,0xff17312a,190,605,350,210);
        for(int i=0;i<9;i++){float x=i*49-28+sway*(i%2==0?1:-1);
          line(c,x,780,x+15,320-i%3*60,0xff0a2222,18+i%3*4);
          for(int j=0;j<5;j++)disk(c,x+15+(j-2)*17,340-i%3*60+j*16,44,0xff135044);
        }break;
      case 5: // snowfall peaks
        mountain(c,0xff37445f,75,590,200,240);mountain(c,0xff182842,290,615,200,320);
        poly(c,0xffd2e2ff,0,580,80,350,145,520,185,390,230,600,360,680,360,780,0,780);
        break;
      case 6: // futuristic horizon
        for(int i=0;i<11;i++){int ht=150+(i*53)%180;float x=i*34;
          c.drawRect(x,630-ht,x+30,780,p(0xff101124));
          for(int j=0;j<ht/16;j++)line(c,x+6,640-ht+j*16,x+22,640-ht+j*16,light,1);
        }
        line(c,0,630,360,630,light,3);break;
      case 7: // roaring flame / dragon head suggestion
        mountain(c,0xff471422,140,610,270,320);mountain(c,0xff241020,260,650,230,300);
        for(int i=0;i<12;i++){float x=i*34;float high=50+((i*33)%110);
          tri(c,i%3==0?0xffffb268:0xffd54b3d,x,780,x+17,680-high+breathing*(i%3),x+40,780);}
        // Dragon wing and snout silhouette: geometric, distinct from a generic fire loop.
        poly(c,0xff120b1d,78,592,112,527,100,466,156,506,202,451,180,524,250,552,213,602,154,621);
        disk(c,156,530,5,light);break;
    }
    // Scene-specific surface decoration: secondary shape keyed by index group.
    if(n>=8&&n<16){
      for(int i=0;i<4;i++){float x=40+i*105;line(c,x,675,x+9,550,0x66ddbbff,4);disk(c,x+9,548,5,light);}
    }
    if(n>=16){
      for(int i=0;i<6;i++){float x=i*73-8;disk(c,x,675+(i%2)*40,12,0x557fffe3);}
    }
    if(particles){Paint dots=p(light);for(int i=0;i<32;i++){
      float x=(i*73+61)%360+(float)Math.sin(t*.37+i*3)*9*move;
      float y=((i*83+193)%780+(float)Math.cos(t*.4+i)*26*move+780)%780;
      dots.setAlpha(70+(i*13)%160);c.drawCircle(x,y,1.1f+(i%3),dots);
    }}
    // Foreground atmospheric vignette.
    c.drawRect(0,750,360,780,p(0x55100919));
    original.restore();
  }
  static void mountain(Canvas c,int color,float peakX,float baseY,float halfWidth,float ht){
    Path m=new Path();m.moveTo(peakX-halfWidth,baseY);m.lineTo(peakX,baseY-ht);m.lineTo(peakX+halfWidth,baseY);m.close();c.drawPath(m,p(color));
  }
  static void castle(Canvas c,float x,float y,int light){
    c.drawRect(x-60,y-180,x+60,y+40,p(0xff140f21));
    c.drawRect(x-85,y-270,x-45,y+30,p(0xff180d20));c.drawRect(x+45,y-270,x+85,y+30,p(0xff180d20));
    poly(c,0xff170a1b,x-98,y-266,x-65,y-327,x-33,y-266);
    poly(c,0xff170a1b,x+32,y-266,x+66,y-327,x+99,y-266);
    poly(c,0xff170a1b,x-70,y-181,x,y-255,x+70,y-181);
    c.drawRoundRect(x-22,y-85,x+22,y+30,18,18,p(0xffc04e2a));
    for(int i=0;i<3;i++){disk(c,x-64,y-219+i*57,8,light);disk(c,x+64,y-219+i*57,8,light);}
  }

  public static class SceneArt {
    public Bitmap background,foreground;
    public void clear(){if(background!=null&&!background.isRecycled())background.recycle();if(foreground!=null&&!foreground.isRecycled())foreground.recycle();background=null;foreground=null;}
    public static SceneArt load(Context context,String key){
      return load(context,key,context.getResources().getDisplayMetrics().widthPixels,context.getResources().getDisplayMetrics().heightPixels);
    }
    public static SceneArt load(Context context,String key,int requestedWidth,int requestedHeight){
      SceneArt a=new SceneArt();try{
        if(key==null)return a;
        if(key.startsWith("built:")){
          int idx=Integer.parseInt(key.substring(6));
          if(idx>=0&&idx<NAMES.length){
            String path="art/world_"+(idx<10?"0":"")+idx;
            for(String ext:new String[]{"jpg","png","webp"}){
              a.background=decodeAsset(context,path+"."+ext,requestedWidth,requestedHeight);
              if(a.background!=null)break;
            }
            a.foreground=decodeAsset(context,path+"_foreground.png",requestedWidth,requestedHeight);
          }
          return a;
        }
        File base=context.getFilesDir();
        if(key.startsWith("image:")){
          String id=key.substring(6);if(!id.matches("[A-Za-z0-9._-]+"))return a;
          a.background=decode(new File(new File(base,"imports"),id),requestedWidth,requestedHeight);
        }else if(key.startsWith("pack:")){
          String id=key.substring(5);if(!id.matches("[A-Za-z0-9._-]+"))return a;
          File folder=new File(new File(base,"packs"),id);
          a.background=decode(new File(folder,"background.png"),requestedWidth,requestedHeight);
          if(a.background==null)a.background=decode(new File(folder,"background.jpg"),requestedWidth,requestedHeight);
          if(a.background==null)a.background=decode(new File(folder,"background.webp"),requestedWidth,requestedHeight);
          a.foreground=decode(new File(folder,"foreground.png"),requestedWidth,requestedHeight);
          if(a.foreground==null)a.foreground=decode(new File(folder,"foreground.webp"),requestedWidth,requestedHeight);
        }
      }catch(Exception ignored){}return a;
    }
    static Bitmap decodeAsset(Context context,String path,int targetWidth,int targetHeight){
      try{
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
        try(java.io.InputStream source=context.getAssets().open(path)){
          BitmapFactory.decodeStream(source,null,bounds);
        }
        if(bounds.outWidth<1||bounds.outHeight<1)return null;
        int sample=1;
        while(bounds.outWidth/(sample*2)>=targetWidth*1.5f&&bounds.outHeight/(sample*2)>=targetHeight*1.5f)sample*=2;
        BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=sample;options.inPreferredConfig=Bitmap.Config.ARGB_8888;
        try(java.io.InputStream source=context.getAssets().open(path)){
          return BitmapFactory.decodeStream(source,null,options);
        }
      }catch(Exception ignored){return null;}
    }
    static Bitmap decode(File file,int targetWidth,int targetHeight){
      if(!file.isFile())return null;try{
        BitmapFactory.Options bounds=new BitmapFactory.Options();bounds.inJustDecodeBounds=true;
        BitmapFactory.decodeFile(file.getAbsolutePath(),bounds);
        if(bounds.outWidth<1||bounds.outHeight<1||bounds.outWidth>30000||bounds.outHeight>30000)return null;
        // Decode near the requested output, not permanently at an arbitrary 1600px limit.
        // An oversampled image helps Android downscale cleanly, without huge allocations.
        int targetW=Math.max(256,Math.min(4096,targetWidth));
        int targetH=Math.max(256,Math.min(4096,targetHeight));
        int sample=1;
        while(bounds.outWidth/(sample*2)>=targetW*1.5f && bounds.outHeight/(sample*2)>=targetH*1.5f)sample*=2;
        while(((long)(bounds.outWidth/sample))*(bounds.outHeight/sample)>24000000L)sample*=2;
        BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=sample;opts.inPreferredConfig=Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeFile(file.getAbsolutePath(),opts);
      }catch(Exception ex){return null;}
    }
  }
}
