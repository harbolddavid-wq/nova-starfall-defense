package com.nova.lockscapes;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

/** Battery-aware animated wallpaper: only schedules frames while visible. */
public class LockscapeWallpaperService extends WallpaperService {
  @Override public Engine onCreateEngine(){return new SceneEngine();}
  final class SceneEngine extends Engine implements SensorEventListener, SharedPreferences.OnSharedPreferenceChangeListener {
    final SharedPreferences prefs=getSharedPreferences("lockscapes",MODE_PRIVATE);
    final Handler handler=new Handler(Looper.getMainLooper());
    final SensorManager sensorManager=(SensorManager)getSystemService(Context.SENSOR_SERVICE);
    final Sensor accelerometer=sensorManager==null?null:sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    Worlds.SceneArt art=new Worlds.SceneArt();
    String key="built:0";
    boolean visible=false,closed=false;
    float tiltX=0,tiltY=0;
    long started=SystemClock.uptimeMillis();
    final Runnable render=new Runnable(){@Override public void run(){paintFrame();}};
    SceneEngine(){super();prefs.registerOnSharedPreferenceChangeListener(this);loadScene();}
    void loadScene(){String next=prefs.getString("scene","built:0");
      if(next.equals(key) && ((next.startsWith("built:")&&!next.equals("built:0"))||(art.background!=null)))return;
      art.clear();key=next;art=Worlds.SceneArt.load(LockscapeWallpaperService.this,key);
      started=SystemClock.uptimeMillis();schedule();
    }
    @Override public void onSharedPreferenceChanged(SharedPreferences preferences,String k){
      if("scene".equals(k))loadScene();else schedule();
      if("tilt".equals(k))registerSensor();
    }
    void schedule(){handler.removeCallbacks(render);if(visible&&!closed)handler.post(render);}
    void registerSensor(){if(sensorManager==null||accelerometer==null)return;
      sensorManager.unregisterListener(this);
      if(visible&&prefs.getBoolean("tilt",true))sensorManager.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_UI);
    }
    @Override public void onSensorChanged(SensorEvent event){if(event.sensor.getType()!=Sensor.TYPE_ACCELEROMETER)return;
      tiltX=tiltX*.87f+(event.values[0]/9.8f)*.13f;
      tiltY=tiltY*.87f+(event.values[1]/9.8f)*.13f;
    }
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}
    @Override public void onVisibilityChanged(boolean showing){super.onVisibilityChanged(showing);visible=showing;
      registerSensor();schedule();}
    @Override public void onSurfaceCreated(SurfaceHolder holder){super.onSurfaceCreated(holder);schedule();}
    @Override public void onSurfaceChanged(SurfaceHolder holder,int format,int w,int h){super.onSurfaceChanged(holder,format,w,h);schedule();}
    @Override public void onSurfaceDestroyed(SurfaceHolder holder){handler.removeCallbacks(render);super.onSurfaceDestroyed(holder);}
    void paintFrame(){handler.removeCallbacks(render);if(closed||!visible)return;
      SurfaceHolder holder=getSurfaceHolder();Canvas c=null;
      try{
        c=holder.lockCanvas();
        if(c!=null){
          float seconds=(SystemClock.uptimeMillis()-started)/1000f;
          float strength=prefs.getInt("motion",55)/100f;
          Worlds.draw(c,c.getWidth(),c.getHeight(),key,art,seconds,strength,tiltX,tiltY,prefs.getBoolean("particles",true),prefs.getInt("fitMode",0),prefs.getInt("zoom",0),prefs.getInt("panX",100),prefs.getInt("panY",100));
        }
      }catch(Exception ignored){}finally{
        if(c!=null){try{holder.unlockCanvasAndPost(c);}catch(Exception ignored){}}
      }
      // 24 frames per second, no rendering when hidden or destroyed.
      if(visible&&!closed)handler.postDelayed(render,42);
    }
    @Override public void onDestroy(){closed=true;visible=false;handler.removeCallbacks(render);
      if(sensorManager!=null)sensorManager.unregisterListener(this);
      prefs.unregisterOnSharedPreferenceChangeListener(this);art.clear();super.onDestroy();}
  }
}
