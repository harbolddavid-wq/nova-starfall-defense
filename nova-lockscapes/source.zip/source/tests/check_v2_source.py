"""Static source checks; do not mistake for Android compilation or on-device QA."""
from pathlib import Path
from hashlib import sha256
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/nova/lockscapes/MainActivity.java').read_text()
worlds=(root/'app/src/main/java/com/nova/lockscapes/Worlds.java').read_text()
service=(root/'app/src/main/java/com/nova/lockscapes/LockscapeWallpaperService.java').read_text()
build=(root/'app/build.gradle').read_text()
checks={
 'same applicationId':'com.nova.lockscapes' in build,
 'version bump':'versionCode 2' in build,
 'bytes copied, no JPEG transcoding':'new FileOutputStream(dest)' in main and 'bmp.compress' not in main,
 'source format recognized': all(s in main for s in ('ext="png"','ext="jpg"','ext="webp"')),
 'old 1600 wallpaper cap removed':'1600f/Math.max(width,height)' not in main,
 '3 framing modes':all(s in main for s in ('Fill screen (crop edges)','Fit entire image (no crop)','Custom crop and position')),
 'live wallpaper honors crop preferences':'prefs.getInt("fitMode",0)' in service,
 'no default photo vignette':'vignette(canvas,width,height)' not in worlds,
 'HD art loading':'"art/world_"' in worlds,
 'release signing opt-in':'NOVA_LOCKSCAPES_KEYSTORE' in build,
}
for k,ok in checks.items():print(('PASS' if ok else 'FAIL'),k)
assert all(checks.values())
asset=root/'app/src/main/assets/art/world_00.jpg'
assert asset.is_file()
print('PASS bundled HD sample bytes:',asset.stat().st_size,'SHA256',sha256(asset.read_bytes()).hexdigest())
