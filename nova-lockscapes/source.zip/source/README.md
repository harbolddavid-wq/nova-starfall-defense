# Nova Lockscapes 2.0-beta1 — quality-first update

**Status:** Source update prepared, *not* yet compiled or installed. The 0.1 APK remains the working version.

Native Java Android wallpaper app for the BLU ViewPro 5G (Android 16); package ID stays `com.nova.lockscapes`. No ads, internet permission, accounts or tracking. Version code increases from 1 to 2. The app retains the original live-wallpaper service and lock/home static-wallpaper actions.

## Fixes in this source

- Imported PNG, JPG, and WEBP files are **copied byte-for-byte** to private app storage. No conversion to JPEG; no lossy recompression; no forced 1600px downsampling on import. Up to 60 MB and 150 megapixels, with additional decoder memory safeguards.
- Render target for static wallpaper uses the phone's display size, not the old 1600px wallpaper cap (protective maximum 4096px for unusual displays).
- Wallpaper drawing applies high-quality bitmap filtering; imported artwork has no forced vignette or tint. Static rendering doesn't insert animated dust on top of photos.
- Three framing modes in the preview: Fill (center crop), Fit (entire image with bars where necessary), Custom (up to 250% zoom with horizontal/vertical position sliders). These settings apply to static and live modes.
- Built-in art engine can render detailed source-image art in place of simple drawn geometry. The first HD demonstration is **Inferno Gate · HD**, using the lava artwork provided as a reference in this conversation; the other 23 worlds remain the original procedural style for now. For later upgrades, add portrait artwork at `app/src/main/assets/art/world_01.jpg` through `world_23.jpg` (PNG/WebP also supported); optional transparent `world_01_foreground.png` enables two-layer motion. This is **not** a completed 24-world realistic art replacement.
- Existing imports from 0.1 still load, but **they were already JPEG-resaved** when imported. Re-import from the untouched original image to benefit from the quality fix.

## Known tradeoffs and limitations

- Landscape images cropped to a tall lock screen will lose content at the sides in **Fill**, because of their aspect ratio. **Fit** preserves the composition but shows borders. No mode can recreate pixels absent from the source image.
- A single photo remains a 2D surface; it can be given subtle motion, but not real 3D depth unless a foreground PNG layer is supplied in a Nova Scene Pack ZIP.
- Android decides whether the live-wallpaper chooser offers a lock-only option. The app cannot guarantee it on every phone.
- This beta has not been compiled or tested on the BLU phone yet. Existing Android 0.1 should remain installed until the matching-signature update APK can be built and tested.

## Build the Android project

Requires **Java 17**, **Gradle 8.9**, **Android SDK platform 35**, **Android build-tools 35.0.0**, and internet access for Gradle's Android plugin dependencies.

```bash
gradle :app:assembleDebug
```

The debug APK is for testing on a separate installation; it is **not** signed with the original 0.1 release key and cannot normally update the currently installed app.

For an *in-place update* of `com.nova.lockscapes`, use the **original private signing backup** (kept separately in your Library; never put the key in this source ZIP or a public repo):

```bash
export NOVA_LOCKSCAPES_KEYSTORE=/private/path/nova_lockscapes_release.p12
export NOVA_LOCKSCAPES_KEY_ALIAS=lockscapes
export NOVA_LOCKSCAPES_KEYPASS='PASSWORD_FROM_PRIVATE_BACKUP'
# If key password differs from store password, export NOVA_LOCKSCAPES_KEY_PASSWORD

gradle :app:assembleRelease
```

This produces `app/build/outputs/apk/release/app-release.apk`. The original backup was locally verified to match the certificate on `Nova_Lockscapes_0.1.apk`; no private signing material is bundled in this source package.

GitHub Actions workflow is included to build and download a *debug* APK on a prepared repo branch. It does **not** publish the private key or claim to generate an install-over-0.1 APK.
