package com.novasky.starlightdream;
import java.io.*;
/** Complete and close the bytes before making an export visible. Keep source for retries. */
public final class ExportFiles {
 public interface Destination {OutputStream open() throws Exception;void publish() throws Exception;void discard();}
 public static void write(File source,Destination destination)throws Exception {
  try {
   if(!source.isFile()||source.length()==0)throw new IOException("The prepared export is missing. Export the drawing again.");
   long expected=source.length(),written=0;
   try(InputStream in=new FileInputStream(source);OutputStream out=destination.open()){
    if(out==null)throw new IOException("The destination could not be opened. Try Save to Downloads.");
    byte[] buffer=new byte[65536];int count;while((count=in.read(buffer))!=-1){out.write(buffer,0,count);written+=count;}out.flush();
    if(written!=expected)throw new IOException("Export was incomplete. Please retry.");
   }
   destination.publish();
  }catch(Exception e){destination.discard();throw e;}
 }
}
