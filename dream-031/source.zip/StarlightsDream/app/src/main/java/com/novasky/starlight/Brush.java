package com.novasky.starlightdream;
import org.json.*;
import java.util.*;
public final class Brush {
 public String id,name,family,kind;public float size=12,flow=.8f,spacing=.13f,hardness=1,scatter=0,aspect=1,taper=0,jitter=0;public int tips=1;public boolean pressure=true;
 public Brush(String id,String name,String family,String kind){this.id=id;this.name=name;this.family=family;this.kind=kind;}
 public JSONObject json(){JSONObject o=new JSONObject();try{o.put("id",id).put("name",name).put("family",family).put("kind",kind).put("size",size).put("flow",flow).put("spacing",spacing).put("hardness",hardness).put("scatter",scatter).put("aspect",aspect).put("taper",taper).put("jitter",jitter).put("tips",tips).put("pressure",pressure);}catch(Exception ignored){}return o;}
 public static Brush from(JSONObject o){Brush b=new Brush(o.optString("id","custom"),o.optString("name","Custom"),o.optString("family","Custom"),o.optString("kind","round"));b.size=(float)o.optDouble("size",12);b.flow=(float)o.optDouble("flow",.8);b.spacing=(float)o.optDouble("spacing",.13);b.hardness=(float)o.optDouble("hardness",1);b.scatter=(float)o.optDouble("scatter",0);b.aspect=(float)o.optDouble("aspect",1);b.taper=(float)o.optDouble("taper",0);b.jitter=(float)o.optDouble("jitter",0);b.tips=o.optInt("tips",1);b.pressure=o.optBoolean("pressure",true);return b;}
 public static List<Brush> catalog(){List<Brush> out=new ArrayList<>();
  add(out,"Pencils","grain",new String[]{"HB sketch","2B soft lead","6B velvet","Drafting pencil","Blue construction","Rough graphite","Shading pencil","Fine mechanical"},new float[]{5,9,18,3,7,13,30,2});
  add(out,"Inks","round",new String[]{"Studio pen","Fine liner","Brush ink","Bold contour","Comic nib","Round marker","Calligraphy","Tapered script"},new float[]{7,3,16,14,9,24,20,13});
  add(out,"Paint","paint",new String[]{"Flat acrylic","Round gouache","Dry bristle","Soft watercolor","Wash glaze","Thick impasto","Wide marker","Ribbon paint"},new float[]{30,36,40,50,85,28,48,24});
  add(out,"Shading","soft",new String[]{"Airbrush","Soft shadow","Velvet blend","Cloud wash","Gentle blush","Deep atmosphere","Edge shader","Soft light"},new float[]{64,90,42,120,55,145,28,75});
  add(out,"Textures","grain",new String[]{"Charcoal","Chalk dust","Canvas grain","Fine stipple","Coarse stipple","Crosshatch","Scratched ink","Speckled wash"},new float[]{32,24,40,12,26,36,30,62});
  add(out,"Hair & fur","hair",new String[]{"Fine hair","Flowing locks","Fur tuft","Soft undercoat","Bristle comb","Whiskers","Feather strands","Wild mane"},new float[]{20,36,30,44,26,12,38,52});
  add(out,"Patterns","star",new String[]{"Little stars","Hearts","Petals","Leaves","Snowflakes","Pearls","Diamond chain","Stitched line"},new float[]{24,28,34,30,34,18,23,14});
  add(out,"Starlight","spark",new String[]{"Stardust","Glitter trail","Shooting stars","Constellation","Galaxy mist","Prism sparks","Neon glow","Firefly light"},new float[]{32,25,44,52,96,36,18,30});
  add(out,"Details","round",new String[]{"Eyelash ink","Freckle scatter","Fabric stitch","Scale pattern","Lace flowers","Tiny dots","Hatching pen","Pixel pen"},new float[]{5,14,14,26,30,6,18,8});
  add(out,"Blending","smudge",new String[]{"Soft smudge","Finger blend","Fine blender","Broad blender","Grain blender","Hard eraser","Soft eraser","Textured eraser"},new float[]{36,50,15,80,32,30,55,40});
  String[] natureNames={"Meadow grass","Fine grass","Daisy blossoms","Wildflower scatter","Brickwork","Rough stone"};String[] natureKinds={"grass","grass","daisy","daisy","brick","stone"};
  for(int i=0;i<natureNames.length;i++){Brush n=new Brush("nature"+i,natureNames[i],"Nature & masonry",natureKinds[i]);n.size=new float[]{45,24,38,25,64,46}[i];n.spacing=new float[]{.5f,.35f,1.1f,.85f,.95f,.8f}[i];n.flow=.9f;n.scatter=i==3?.6f:0;n.tips=i==1?9:5;n.pressure=false;out.add(n);}
  return out;
 }
 private static void add(List<Brush> out,String family,String base,String[] names,float[] sizes){for(int i=0;i<names.length;i++){Brush b=new Brush("b"+out.size(),names[i],family,base);b.size=sizes[i];
  if(family.equals("Pencils")){b.flow=.3f+i*.035f;b.hardness=.65f;b.tips=7+i;b.spacing=.11f;b.aspect=i==6?.4f:1;}
  if(family.equals("Inks")){b.flow=1;b.spacing=.08f;b.taper=(i==2||i==4||i==7)?.65f:0;b.aspect=i==6?.24f:1;}
  if(family.equals("Paint")){b.flow=.25f+i*.07f;b.aspect=i==0||i==6?.3f:1;b.tips=5+i;b.kind=i==3||i==4?"soft":i==7?"ribbon":"paint";b.hardness=i==3?.25f:.8f;b.spacing=.12f;}
  if(family.equals("Shading")){b.flow=.07f+i*.012f;b.hardness=.05f;b.spacing=.16f;b.aspect=i==6?.35f:1;}
  if(family.equals("Textures")){b.flow=.4f;b.tips=4+i*2;b.scatter=.2f;b.spacing=.22f;b.kind=i==5?"hatch":i==6?"scratch":"grain";}
  if(family.equals("Hair & fur")){b.kind="hairSmooth";b.flow=.65f;b.tips=new int[]{5,9,7,12,6,2,8,11}[i];b.spacing=.08f;b.taper=.8f;b.aspect=.5f+i*.06f;}
  if(family.equals("Patterns")){b.kind=new String[]{"star","heart","flower","leaf","snow","pearl","diamond","stitch"}[i];b.flow=.9f;b.spacing=1.05f;b.pressure=false;}
  if(family.equals("Starlight")){b.kind=new String[]{"spark","grain","star","constellation","soft","spark","glow","glow"}[i];b.scatter=.5f;b.jitter=i==5?.18f:.05f;b.flow=i==4?.10f:.6f;b.spacing=i==4?.35f:.65f;b.tips=6+i;b.hardness=.1f;}
  if(family.equals("Details")){b.kind=new String[]{"round","grain","stitch","scale","flower","round","hatch","pixel"}[i];b.taper=i==0?.85f:0;b.spacing=i==0?.08f:i==1?.7f:i==5?1.4f:.9f;b.flow=.85f;b.scatter=i==1?.45f:0;}
  if(family.equals("Blending")){b.flow=.14f+i*.04f;b.kind=i>=5?(i==6?"soft":i==7?"grain":"round"):"smudge";b.hardness=i==5?1:.15f;b.spacing=.16f;b.tips=10;}
  out.add(b);
 }}
}
