package com.novasky.starlightdream;
import android.graphics.*;
public final class PhotoCleaner {
 /** Adjustable local paper normalization. No generative tracing or line reshaping. */
 public static Bitmap clean(Bitmap source,float strength,int paperCut,boolean shadow,boolean color){int w=source.getWidth(),h=source.getHeight(),cell=32,cols=(w+cell-1)/cell,rows=(h+cell-1)/cell;int[] pix=new int[w*h];source.getPixels(pix,0,w,0,0,w,h);float[] light=new float[cols*rows];for(int y=0;y<h;y++)for(int x=0;x<w;x++){int c=pix[y*w+x];float v=.2126f*Color.red(c)+.7152f*Color.green(c)+.0722f*Color.blue(c);int i=(y/cell)*cols+x/cell;light[i]=Math.max(light[i],v);}
  for(int y=0;y<h;y++)for(int x=0;x<w;x++){int i=y*w+x,c=pix[i];float lum=.2126f*Color.red(c)+.7152f*Color.green(c)+.0722f*Color.blue(c);float fx=Math.max(0,x/(float)cell-.5f),fy=Math.max(0,y/(float)cell-.5f);int cx=Math.min(cols-1,(int)fx),cy=Math.min(rows-1,(int)fy),nx=Math.min(cols-1,cx+1),ny=Math.min(rows-1,cy+1);float tx=Math.min(1,fx-cx),ty=Math.min(1,fy-cy);float local=light[cy*cols+cx]*(1-tx)*(1-ty)+light[cy*cols+nx]*tx*(1-ty)+light[ny*cols+cx]*(1-tx)*ty+light[ny*cols+nx]*tx*ty;float normalized=shadow?Math.min(255,lum*255/Math.max(64,local)):lum;float deficit=Math.max(0,255-normalized-paperCut);int alpha=Math.min(255,Math.round(deficit*strength*255/Math.max(1,255-paperCut)));alpha=alpha*Color.alpha(c)/255;pix[i]=Color.argb(alpha,color?Color.red(c):0,color?Color.green(c):0,color?Color.blue(c):0);}
  Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);out.setPixels(pix,0,w,0,0,w,h);return out;
 }
}
