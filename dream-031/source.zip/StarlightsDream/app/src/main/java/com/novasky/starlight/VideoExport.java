package com.novasky.starlightdream;
import android.graphics.*;
import android.media.*;
import java.io.*;
import java.nio.*;

public final class VideoExport {
 public interface Progress {void update(int percent);}
 /** Uses Android's H.264 encoder with explicit YUV image plane strides. */
 public static void encode(Project project,File output,int seconds,Progress progress)throws Exception {
  int width=project.doc.width,height=project.doc.height;float scale=Math.min(1,640f/Math.max(width,height));width=Math.max(64,((int)(width*scale)/2)*2);height=Math.max(64,((int)(height*scale)/2)*2);int fps=12,frames=seconds*fps;
  MediaCodec codec=null;MediaMuxer muxer=null;Replay replay=null;Bitmap frame=null;boolean muxStarted=false;int track=-1;MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
  try{codec=MediaCodec.createEncoderByType("video/avc");MediaFormat f=MediaFormat.createVideoFormat("video/avc",width,height);f.setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible);f.setInteger(MediaFormat.KEY_BIT_RATE,2000000);f.setInteger(MediaFormat.KEY_FRAME_RATE,fps);f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,1);codec.configure(f,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);codec.start();muxer=new MediaMuxer(output.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);replay=new Replay(project);frame=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);int[] pixels=new int[width*height];int next=0;boolean inputEnd=false,outputEnd=false;long lastOutput=System.currentTimeMillis();
   while(!outputEnd){if(Thread.currentThread().isInterrupted())throw new IOException("Export cancelled");if(!inputEnd){int input=codec.dequeueInputBuffer(10000);if(input>=0){if(next>=frames){codec.queueInputBuffer(input,0,0,next*1000000L/fps,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputEnd=true;}else{float step=project.timeline.size()*Math.min(1,next/(float)Math.max(1,frames-fps*2-1));replay.seek(step);frame.eraseColor(Color.WHITE);Canvas canvas=new Canvas(frame);canvas.save();canvas.scale(width/(float)project.doc.width,height/(float)project.doc.height);replay.doc.composite(canvas,true);canvas.restore();frame.getPixels(pixels,0,width,0,0,width,height);
     Image image=codec.getInputImage(input);if(image==null)throw new IOException("This device’s encoder does not expose a supported YUV input image.");fillYuv(image,pixels,width,height);codec.queueInputBuffer(input,0,width*height*3/2,next*1000000L/fps,0);next++;progress.update(next*100/frames);}}}
    int index=codec.dequeueOutputBuffer(info,10000);if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){if(muxStarted)throw new IOException("Encoder changed format twice");track=muxer.addTrack(codec.getOutputFormat());muxer.start();muxStarted=true;}else if(index>=0){ByteBuffer data=codec.getOutputBuffer(index);if((info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)!=0)info.size=0;if(info.size>0){if(!muxStarted)throw new IOException("Encoder output arrived before its format");data.position(info.offset);data.limit(info.offset+info.size);muxer.writeSampleData(track,data,info);lastOutput=System.currentTimeMillis();}outputEnd=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;codec.releaseOutputBuffer(index,false);}if(System.currentTimeMillis()-lastOutput>60000)throw new IOException("Video encoder timed out; your drawing is saved.");
   }
  }finally{if(replay!=null)replay.close();if(frame!=null)frame.recycle();if(codec!=null){try{codec.stop();}catch(Exception ignored){}codec.release();}if(muxer!=null){if(muxStarted)try{muxer.stop();}catch(Exception ignored){}muxer.release();}}
 }
 static void fillYuv(Image image,int[] pixels,int w,int h){Image.Plane[] planes=image.getPlanes();for(int y=0;y<h;y++)for(int x=0;x<w;x++){int c=pixels[y*w+x],r=Color.red(c),g=Color.green(c),b=Color.blue(c);int yy=((66*r+129*g+25*b+128)>>8)+16;put(planes[0],x,y,yy);if((y&1)==0&&(x&1)==0){int u=((-38*r-74*g+112*b+128)>>8)+128,v=((112*r-94*g-18*b+128)>>8)+128;put(planes[1],x/2,y/2,u);put(planes[2],x/2,y/2,v);}}}
 static void put(Image.Plane plane,int x,int y,int value){ByteBuffer b=plane.getBuffer();b.put(b.position()+y*plane.getRowStride()+x*plane.getPixelStride(),(byte)Math.max(0,Math.min(255,value)));}
}
