package com.novasky.starlightdream;
import android.content.*;
import android.database.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.*;
public final class ShareProvider extends ContentProvider {
 public boolean onCreate(){return true;}
 private File file(Uri uri)throws FileNotFoundException {try{File root=new File(getContext().getCacheDir(),"exports").getCanonicalFile();File f=new File(root,uri.getLastPathSegment()).getCanonicalFile();if(!f.getParentFile().equals(root))throw new IOException();return f;}catch(Exception e){throw new FileNotFoundException("Invalid export");}}
 public String getType(Uri uri){String n=uri.getLastPathSegment();return n.endsWith(".png")?"image/png":n.endsWith(".mp4")?"video/mp4":"application/zip";}
 public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException {if(!mode.equals("r"))throw new FileNotFoundException("Read only");return ParcelFileDescriptor.open(file(uri),ParcelFileDescriptor.MODE_READ_ONLY);}
 public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort){MatrixCursor c=new MatrixCursor(new String[]{"_display_name","_size"});try{File f=file(uri);c.addRow(new Object[]{f.getName(),f.length()});}catch(Exception ignored){}return c;}
 public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
}
