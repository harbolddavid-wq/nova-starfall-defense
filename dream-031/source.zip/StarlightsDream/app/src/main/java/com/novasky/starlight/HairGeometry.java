package com.novasky.starlightdream;
import java.util.*;
/** Continuous quadratic centerline with stable strand offsets; no per-dab randomness. */
public final class HairGeometry {
 public static float[][][] strands(List<float[]> points,int count,float size,float aspect,int tips,float taper,long seed,boolean pressure){
  count=Math.min(count,points.size());if(count==0)return new float[0][][];
  ArrayList<float[]> centers=new ArrayList<>();float[] first=points.get(0);float sx=first[0],sy=first[1],sp=first[2];
  float nx=0,ny=1;
  for(int i=0;i<count;i++){float[] control=points.get(i),next=points.get(Math.min(count-1,i+1));float ex=i==count-1?control[0]:(control[0]+next[0])/2,ey=i==count-1?control[1]:(control[1]+next[1])/2,ep=i==count-1?control[2]:(control[2]+next[2])/2;int steps=Math.max(1,Math.min(256,(int)Math.ceil((Math.hypot(control[0]-sx,control[1]-sy)+Math.hypot(ex-control[0],ey-control[1]))/1.5)));
   for(int j=0;j<=steps;j++){if(i>0&&j==0)continue;float t=j/(float)steps,u=1-t,x=u*u*sx+2*u*t*control[0]+t*t*ex,y=u*u*sy+2*u*t*control[1]+t*t*ey;float dx=2*u*(control[0]-sx)+2*t*(ex-control[0]),dy=2*u*(control[1]-sy)+2*t*(ey-control[1]);float len=(float)Math.hypot(dx,dy);if(len>.0001f){nx=-dy/len;ny=dx/len;}float p=pressure?Math.max(.15f,Math.min(1.5f,u*u*sp+2*u*t*control[2]+t*t*ep)):1;centers.add(new float[]{x,y,nx,ny,p});}
   sx=ex;sy=ey;sp=ep;
  }
  tips=Math.max(1,Math.min(32,tips));float[][][] out=new float[tips][centers.size()][2];Random random=new Random(seed);for(int k=0;k<tips;k++){float offset=tips==1?0:(k/(float)(tips-1)-.5f);offset+=(random.nextFloat()-.5f)*.08f/Math.max(1,tips);for(int j=0;j<centers.size();j++){float t=centers.size()<2?.5f:j/(float)(centers.size()-1);float edge=Math.min(1,Math.min(t*6,(1-t)*6));float spread=(1-taper)+taper*(float)Math.sin(edge*Math.PI/2);float[] c=centers.get(j);float distance=offset*size*aspect*spread*c[4];out[k][j][0]=c[0]+c[2]*distance;out[k][j][1]=c[1]+c[3]*distance;}}
  return out;
 }
}
