package com.novasky.starlightdream;
import android.graphics.*;
import org.json.*;
import java.io.*;
import java.util.*;
public final class ArtDocument {
 public int overlayColor=0xffb29add;public float overlayAmount=0;public String moveFolder="";public float moveX=0,moveY=0;
 public final int width,height;public String title;public int background=Color.WHITE,fillOverlap=-1;public String active="base",fillReference="";public final ArrayList<Layer> layers=new ArrayList<>();public final LinkedHashMap<String,Folder> folders=new LinkedHashMap<>();public File directory;
 public static final class Folder {public final String name;public float opacity=1;public boolean visible=true;
  Folder(String name){this.name=name;}
  JSONObject json(){JSONObject o=new JSONObject();try{o.put("name",name).put("opacity",opacity).put("visible",visible);}catch(JSONException ignored){}return o;}
  void read(JSONObject o){opacity=Math.max(0,Math.min(1,(float)o.optDouble("opacity",1)));visible=o.optBoolean("visible",true);}
 }
 public Folder folder(String name){if(name==null||name.isEmpty())return null;Folder f=folders.get(name);if(f==null){f=new Folder(name);folders.put(name,f);}return f;}
 public static final class Layer {public String id,name;public Bitmap pixels;public float opacity=1;public boolean visible=true,locked=false,alphaLock=false,clip=false,sketch=false;public String blend="Normal",folder="",clipFolder="";public int overlayColor=0xffb29add;public float overlayAmount=0;
  Layer(String id,String name,Bitmap b){this.id=id;this.name=name;pixels=b;}
  JSONObject json(){JSONObject o=new JSONObject();try{o.put("id",id).put("name",name).put("opacity",opacity).put("visible",visible).put("locked",locked).put("alphaLock",alphaLock).put("clip",clip).put("sketch",sketch).put("blend",blend).put("folder",folder).put("clipFolder",clipFolder).put("overlayColor",overlayColor).put("overlayAmount",overlayAmount);}catch(Exception ignored){}return o;}
  void read(JSONObject o){name=o.optString("name",name);opacity=(float)o.optDouble("opacity",1);visible=o.optBoolean("visible",true);locked=o.optBoolean("locked");alphaLock=o.optBoolean("alphaLock");clip=o.optBoolean("clip");sketch=o.optBoolean("sketch");blend=o.optString("blend","Normal");folder=o.optString("folder","");clipFolder=o.optString("clipFolder","");overlayColor=o.optInt("overlayColor",0xffb29add);overlayAmount=Math.max(0,Math.min(1,(float)o.optDouble("overlayAmount",0)));}
 }
 public ArtDocument(int w,int h,String title,File directory){if(w<64||h<64||w>2048||h>2048)throw new IllegalArgumentException("Canvas dimensions must be 64–2048 pixels.");width=w;height=h;this.title=title;this.directory=directory;layers.add(new Layer("base","Sketch",empty()));}
 public Bitmap empty(){return Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);}
 public Layer layer(String id){for(Layer l:layers)if(l.id.equals(id))return l;return null;}
 public Layer current(){Layer l=layer(active);return l==null?layers.get(layers.size()-1):l;}
 public int limit(){long budget=Math.max(24L*1024*1024,Runtime.getRuntime().maxMemory()/5);return Math.max(2,Math.min(24,(int)(budget/(width*(long)height*4))));}
 public JSONObject metadata(){JSONObject o=new JSONObject();try{JSONArray a=new JSONArray();for(Layer l:layers)a.put(l.json());o.put("width",width).put("height",height).put("title",title).put("background",background).put("active",active).put("fillReference",fillReference).put("fillOverlap",fillOverlap).put("layers",a).put("folders",folderMetadata()).put("overlayColor",overlayColor).put("overlayAmount",overlayAmount);}catch(Exception ignored){}return o;}
 public JSONArray folderMetadata(){JSONArray a=new JSONArray();for(Folder f:folders.values())a.put(f.json());return a;}
 public void loadFolders(JSONArray data){folders.clear();if(data!=null)for(int i=0;i<data.length();i++){JSONObject o=data.optJSONObject(i);if(o==null)continue;String name=o.optString("name","");if(name.isEmpty()||folders.containsKey(name))continue;Folder f=folder(name);f.read(o);}for(Layer l:layers)if(!l.folder.isEmpty())folder(l.folder);}
 public void normalizeFolder(String name){if(name==null||name.isEmpty())return;ArrayList<Layer> members=new ArrayList<>();int start=-1;for(int i=0;i<layers.size();i++)if(layers.get(i).folder.equals(name)){if(start<0)start=i;members.add(layers.get(i));}if(members.isEmpty())return;layers.removeAll(members);layers.addAll(Math.min(start,layers.size()),members);}
 public boolean groupBelow(Layer layer,String group){int position=layers.indexOf(layer);if(position<0||group.isEmpty())return false;for(int i=0;i<position;i++)if(layers.get(i).folder.equals(group))return true;return false;}
 public String clipTargetName(Layer l){if(!l.clipFolder.isEmpty())return "entire folder: "+l.clipFolder;int i=layers.indexOf(l);return i>0?layers.get(i-1).name:"no layer below";}
 // Group children remain editable individual bitmaps. Render a folder once as a transparent
 // isolated composite so alpha/clipping uses the WHOLE group's painted pixels.
 private void drawMember(Canvas out,Layer l,Layer previous){
  if(!l.visible||l.opacity<=0)return;
  Paint paint=new Paint(3);paint.setAlpha(Math.round(255*l.opacity));paint.setColorFilter(tint(l.overlayColor,l.overlayAmount));paint.setXfermode(blend(l.blend));
  if(l.clip&&previous!=null&&(!previous.visible||previous.opacity<=0))return;
  if(!l.clip||previous==null){out.drawBitmap(l.pixels,0,0,paint);return;}
  Bitmap clipped=empty();try{Canvas dst=new Canvas(clipped);dst.drawBitmap(l.pixels,0,0,paint);Paint mask=new Paint(3);mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));mask.setAlpha(Math.round(255*previous.opacity));dst.drawBitmap(previous.pixels,0,0,mask);out.drawBitmap(clipped,0,0,new Paint(3));}finally{clipped.recycle();}
 }
 private Bitmap folderPixels(String name){Bitmap b=empty();Canvas out=new Canvas(b);Layer previous=null;for(Layer l:layers)if(l.folder.equals(name)){drawMember(out,l,previous);previous=l;}return b;}
 public void composite(Canvas c,boolean paper){
  // Tint the actual rendered canvas, not just the picker thumbnail. Alpha is untouched.
  int whole=-1;if(overlayAmount>0){Paint p=new Paint(3);p.setColorFilter(tint(overlayColor,overlayAmount));whole=c.saveLayer(0,0,width,height,p);}
  if(paper&&Color.alpha(background)>0)c.drawColor(background);
  HashSet<String> seen=new HashSet<>();
  try{Layer previous=null;for(Layer l:layers){
    if(!l.folder.isEmpty()){
      if(seen.add(l.folder)){Folder group=folder(l.folder);if(group.visible&&group.opacity>0){Bitmap b=folderPixels(l.folder);try{Paint p=new Paint(3);p.setAlpha(Math.round(group.opacity*255));int save=c.save();if(l.folder.equals(moveFolder))c.translate(moveX,moveY);c.drawBitmap(b,0,0,p);c.restoreToCount(save);}finally{b.recycle();}}}
      previous=l;continue;
    }
    if(!l.clipFolder.isEmpty()){
      Folder g=folders.get(l.clipFolder);
      if(l.visible&&l.opacity>0&&g!=null&&g.visible&&g.opacity>0&&groupBelow(l,l.clipFolder)){
       Bitmap mask=folderPixels(l.clipFolder);Bitmap clipped=empty();try{Canvas dst=new Canvas(clipped);drawMember(dst,l,null);Paint mp=new Paint(3);mp.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));mp.setAlpha(Math.round(255*g.opacity));dst.drawBitmap(mask,0,0,mp);c.drawBitmap(clipped,0,0,new Paint(3));}finally{clipped.recycle();mask.recycle();}}
    }else drawMember(c,l,previous!=null&&previous.folder.isEmpty()?previous:null);
    previous=l;
  }}finally{if(whole>=0)c.restoreToCount(whole);}
 }
 public static ColorFilter tint(int color,float amount){if(amount<=0)return null;float a=Math.max(0,Math.min(1,amount)),b=1-a;return new ColorMatrixColorFilter(new float[]{b,0,0,0,Color.red(color)*a,0,b,0,0,Color.green(color)*a,0,0,b,0,Color.blue(color)*a,0,0,0,1,0});}
 private static Xfermode blend(String b){if(b.equals("Multiply"))return new PorterDuffXfermode(PorterDuff.Mode.MULTIPLY);if(b.equals("Screen"))return new PorterDuffXfermode(PorterDuff.Mode.SCREEN);if(b.equals("Add"))return new PorterDuffXfermode(PorterDuff.Mode.ADD);return null;}
 public Bitmap mergePreview(Layer upper)throws IOException {int at=layers.indexOf(upper);if(at<=0)throw new IOException("No layer below this layer");ArtDocument pair=new ArtDocument(width,height,"Merge",directory);pair.dispose();try{pair.layers.add(layers.get(at-1));pair.layers.add(upper);return pair.flattened(false);}finally{pair.layers.clear();}}
 public int sampleVisible(int x,int y){if(x<0||y<0||x>=width||y>=height)return Color.TRANSPARENT;Bitmap pixel=Bitmap.createBitmap(1,1,Bitmap.Config.ARGB_8888);try{Canvas c=new Canvas(pixel);c.translate(-x,-y);composite(c,true);return pixel.getPixel(0,0);}finally{pixel.recycle();}}
 public Bitmap flattened(boolean paper){Bitmap b=empty();composite(new Canvas(b),paper);return b;}
 public void apply(JSONObject e)throws Exception {String type=e.getString("type"),id=e.optString("layer",active);Layer l=layer(id);
  switch(type){
   case "overlay":overlayColor=e.getInt("color");overlayAmount=Math.max(0,Math.min(1,(float)e.getDouble("amount")));break;
   case "folderCreate":{String name=e.getString("folder");if(name.isEmpty()||folders.containsKey(name))throw new IOException("Folder already exists");folder(name);JSONArray ids=e.getJSONArray("members");ArrayList<Layer> members=new ArrayList<>();for(int j=0;j<ids.length();j++){Layer child=layer(ids.getString(j));if(child!=null&&!members.contains(child))members.add(child);}if(members.isEmpty())throw new IOException("Select at least one layer");int at=layers.size();for(Layer m:members){at=Math.min(at,layers.indexOf(m));layers.remove(m);m.folder=name;m.clipFolder="";}layers.addAll(Math.min(at,layers.size()),members);break;}
   case "folderUngroup":{String name=e.getString("folder");for(Layer m:layers){if(name.equals(m.folder))m.folder="";if(name.equals(m.clipFolder))m.clipFolder="";}folders.remove(name);break;}
   case "folderProps":{Folder f=folder(e.getString("folder"));if(f==null)throw new IOException("Missing folder");f.read(e.getJSONObject("props"));break;}
   case "clipToFolder":{if(l==null)throw new IOException("Missing layer");String name=e.optString("folder","");if(!name.isEmpty()&&(!folders.containsKey(name)||l.folder.equals(name)))throw new IOException("Pick a different folder");l.clipFolder=name;l.clip=false;if(!name.isEmpty()){ArrayList<Layer> members=new ArrayList<>();for(Layer m:layers)if(m.folder.equals(name))members.add(m);if(members.isEmpty())throw new IOException("That folder is empty");layers.remove(l);int last=layers.indexOf(members.get(members.size()-1));layers.add(Math.min(last+1,layers.size()),l);}break;}
   case "translateFolder":{String folder=e.getString("folder");if(folder.isEmpty())throw new IOException("Choose a folder");ArrayList<Bitmap> changed=new ArrayList<>();ArrayList<Layer> members=new ArrayList<>();try{for(Layer member:layers)if(member.folder.equals(folder)){Bitmap b=empty();changed.add(b);members.add(member);new Canvas(b).drawBitmap(member.pixels,(float)e.getDouble("dx"),(float)e.getDouble("dy"),new Paint(3));}}catch(Throwable ex){for(Bitmap b:changed)b.recycle();throw ex;}for(int i=0;i<members.size();i++){members.get(i).pixels.recycle();members.get(i).pixels=changed.get(i);}break;}
   case "title":title=e.getString("title");break;
   case "group":{JSONArray actions=e.getJSONArray("events");for(int i=0;i<actions.length();i++)apply(actions.getJSONObject(i));break;}
   case "stroke":if(l!=null&&!l.sketch)Raster.stroke(l.pixels,Raster.Stroke.from(e.getJSONObject("stroke")),l.alphaLock,1);break;
   case "fillOverlap":fillOverlap=Math.max(-1,Math.min(8,e.optInt("pixels",-1)));break;
   case "fillReference":fillReference=e.optString("reference","");break;
   case "fill":if(l!=null&&!l.sketch){String ref=e.optString("reference","");int overlap=e.optInt("overlap",0);if(ref.isEmpty()&&overlap==0)Raster.fill(l.pixels,e.getInt("x"),e.getInt("y"),e.getInt("color"),e.optInt("tolerance",20),l.alphaLock);else{Layer boundary=ref.isEmpty()?l:layer(ref);if(boundary==null)throw new IOException("Fill reference layer is missing");Raster.fillUsingReference(l.pixels,boundary.pixels,e.getInt("x"),e.getInt("y"),e.getInt("color"),e.optInt("tolerance",20),l.alphaLock,overlap);}}break;
   case "add":{Layer n=new Layer(e.getString("id"),e.optString("name","Layer"),empty());int at=e.optInt("at",layers.size());layers.add(Math.max(0,Math.min(at,layers.size())),n);active=n.id;break;}
   case "duplicate":if(l!=null){Layer n=new Layer(e.getString("id"),l.name+" copy",l.pixels.copy(Bitmap.Config.ARGB_8888,true));n.read(l.json());n.name=l.name+" copy";n.locked=false;layers.add(layers.indexOf(l)+1,n);active=n.id;}break;
   case "delete":if(l!=null&&layers.size()>1){layers.remove(l);l.pixels.recycle();if(fillReference.equals(l.id))fillReference="";if(active.equals(l.id))active=layers.get(layers.size()-1).id;}break;
   case "props":if(l!=null){String before=l.folder;l.read(e.getJSONObject("props"));if(!l.folder.isEmpty()){folder(l.folder);normalizeFolder(l.folder);}if(!before.isEmpty()&&!before.equals(l.folder))normalizeFolder(before);}break;
   case "reorder":if(l!=null){String group=l.folder;layers.remove(l);layers.add(Math.max(0,Math.min(e.getInt("to"),layers.size())),l);if(!group.isEmpty())normalizeFolder(group);}break;
   case "clear":if(l!=null&&!l.sketch)l.pixels.eraseColor(Color.TRANSPARENT);break;
   case "background":background=e.getInt("color");break;
   case "merge":if(l!=null){int at=layers.indexOf(l);if(at>0){Layer lower=layers.get(at-1);Paint p=new Paint(3);p.setAlpha((int)(255*l.opacity));p.setXfermode(blend(l.blend));new Canvas(lower.pixels).drawBitmap(l.pixels,0,0,p);layers.remove(l);l.pixels.recycle();active=lower.id;}}break;
   case "replacePixels":{if(l==null)throw new IOException("Layer no longer exists");Bitmap b=BitmapFactory.decodeFile(asset(e.getString("asset")).getAbsolutePath());if(b==null)throw new IOException("Missing transformed image");try{if(b.getWidth()!=width||b.getHeight()!=height)throw new IOException("Invalid transformed dimensions");l.pixels.eraseColor(Color.TRANSPARENT);new Canvas(l.pixels).drawBitmap(b,0,0,null);}finally{b.recycle();}break;}
   case "image":{if(e.has("cut")&&l!=null){Paint p=new Paint(3);p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));new Canvas(l.pixels).drawPath(path(e.getJSONArray("cut")),p);}String file=e.getString("asset");Bitmap b=BitmapFactory.decodeFile(asset(file).getAbsolutePath());if(b==null)throw new IOException("Image asset is missing: "+file);Layer n=new Layer(e.getString("id"),e.optString("name","Imported image"),empty());Matrix m=new Matrix();JSONArray values=e.getJSONArray("matrix");float[] data=new float[9];for(int i=0;i<9;i++)data[i]=(float)values.getDouble(i);m.setValues(data);new Canvas(n.pixels).drawBitmap(b,m,new Paint(3));b.recycle();n.locked=e.optBoolean("locked");layers.add(n);active=n.id;break;}
   default:throw new IOException("Unknown drawing action: "+type);
  }
 }
 public File asset(String name)throws IOException {if(name.contains("/")||name.contains("\\")||name.contains(".."))throw new IOException("Invalid asset name");return new File(new File(directory,"assets"),name);}
 public static Path path(JSONArray a){Path p=new Path();for(int i=0;i<a.length();i++){JSONArray v=a.optJSONArray(i);if(v==null)continue;float x=(float)v.optDouble(0),y=(float)v.optDouble(1);if(i==0)p.moveTo(x,y);else p.lineTo(x,y);}p.close();return p;}
 public static JSONArray matrix(Matrix m){float[] a=new float[9];m.getValues(a);JSONArray j=new JSONArray();for(float f:a)j.put((Object)Float.valueOf(f));return j;}
 public void dispose(){for(Layer l:layers)if(l.pixels!=null&&!l.pixels.isRecycled())l.pixels.recycle();layers.clear();}
}
