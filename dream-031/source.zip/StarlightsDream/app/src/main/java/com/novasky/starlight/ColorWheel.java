package com.novasky.starlightdream;
import android.content.Context;
import android.graphics.*;
import android.view.*;
public final class ColorWheel extends View {
 public interface Listener {void color(int value);}
 public float hue=280,saturation=.5f,value=.8f;public Listener listener;private final Paint paint=new Paint(3);
 public ColorWheel(Context c,int color,Listener l){super(c);float[] hsv=new float[3];Color.colorToHSV(color,hsv);hue=hsv[0];saturation=hsv[1];value=hsv[2];listener=l;setContentDescription("Color wheel: hue around the circle, saturation from center to edge");}
 public int color(){return Color.HSVToColor(new float[]{hue,saturation,value});}
 protected void onDraw(Canvas c){float x=getWidth()/2f,y=getHeight()/2f,r=Math.min(x,y)-12;int[] colors={Color.RED,Color.YELLOW,Color.GREEN,Color.CYAN,Color.BLUE,Color.MAGENTA,Color.RED};paint.setShader(new SweepGradient(x,y,colors,null));c.drawCircle(x,y,r,paint);paint.setShader(new RadialGradient(x,y,r,new int[]{Color.WHITE,0x00ffffff},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,r,paint);paint.setShader(null);paint.setColor(Color.argb((int)(255*(1-value)),0,0,0));c.drawCircle(x,y,r,paint);double a=Math.toRadians(hue);float sx=x+(float)Math.cos(a)*r*saturation,sy=y+(float)Math.sin(a)*r*saturation;paint.setColor(Color.WHITE);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3);c.drawCircle(sx,sy,9,paint);paint.setStyle(Paint.Style.FILL);}
 public boolean onTouchEvent(MotionEvent e){float dx=e.getX()-getWidth()/2f,dy=e.getY()-getHeight()/2f,r=Math.min(getWidth(),getHeight())/2f-12;hue=(float)(Math.toDegrees(Math.atan2(dy,dx))+360)%360;saturation=Math.max(0,Math.min(1,(float)Math.hypot(dx,dy)/r));invalidate();listener.color(color());getParent().requestDisallowInterceptTouchEvent(e.getActionMasked()!=MotionEvent.ACTION_UP);return true;}
}
