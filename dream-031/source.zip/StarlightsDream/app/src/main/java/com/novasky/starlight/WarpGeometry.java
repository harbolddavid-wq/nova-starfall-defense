package com.novasky.starlightdream;

/** Reject folds and collapsed edges before Android constructs a perspective matrix. */
public final class WarpGeometry {
 private WarpGeometry() {}
 public static boolean valid(float[] corners) {
  if(corners==null||corners.length!=8)return false;
  for(float v:corners)if(Float.isNaN(v)||Float.isInfinite(v)||Math.abs(v)>100000)return false;
  for(int i=0;i<4;i++){
   int a=i*2,b=((i+1)%4)*2,c=((i+2)%4)*2;
   double dx=corners[b]-corners[a],dy=corners[b+1]-corners[a+1];
   if(dx*dx+dy*dy<1)return false;
   double cross=dx*(corners[c+1]-corners[b+1])-dy*(corners[c]-corners[b]);
   if(cross<1)return false;
  }
  return true;
 }
}
