package com.novasky.starlightdream;
import android.graphics.*;
import org.json.*;
import java.io.*;
import java.util.*;
public final class Replay {
 public ArtDocument doc;public final ArrayList<JSONObject> records;private ArrayList<JSONObject> edits=new ArrayList<>();private int cursor=0,index=0;private Bitmap partialBefore;private String partialLayer;private final int w,h;private final String title;private final File directory;
 public Replay(Project p){w=p.doc.width;h=p.doc.height;title=p.doc.title;directory=p.dir;records=new ArrayList<>(p.timeline);reset();}
 private void reset(){if(doc!=null)doc.dispose();doc=new ArtDocument(w,h,title,directory);index=0;cursor=0;edits.clear();}
 private void clearPartial(){if(partialBefore!=null){ArtDocument.Layer l=doc.layer(partialLayer);if(l!=null){l.pixels.eraseColor(Color.TRANSPARENT);new Canvas(l.pixels).drawBitmap(partialBefore,0,0,null);}partialBefore.recycle();partialBefore=null;}}
 public void seek(float steps)throws Exception {clearPartial();int end=Math.max(0,Math.min(records.size(),(int)Math.floor(steps)));if(end<index)reset();while(index<end){JSONObject r=records.get(index++);if(r.optString("op").equals("edit")){JSONObject e=r.getJSONObject("event");while(edits.size()>cursor)edits.remove(edits.size()-1);edits.add(e);cursor++;doc.apply(e);}else if(r.optString("op").equals("cursor")){cursor=Math.max(0,Math.min(r.optInt("value"),edits.size()));doc.dispose();doc=new ArtDocument(w,h,title,directory);for(int i=0;i<cursor;i++)doc.apply(edits.get(i));}}
  float fraction=steps-end;if(fraction>0&&end<records.size()){JSONObject r=records.get(end),e=r.optJSONObject("event");if(e!=null&&e.optString("type").equals("stroke")){ArtDocument.Layer l=doc.layer(e.optString("layer"));if(l!=null){partialLayer=l.id;partialBefore=l.pixels.copy(Bitmap.Config.ARGB_8888,false);Raster.stroke(l.pixels,Raster.Stroke.from(e.getJSONObject("stroke")),l.alphaLock,fraction);}}}
 }
 public void close(){if(partialBefore!=null)partialBefore.recycle();partialBefore=null;if(doc!=null)doc.dispose();}
}
