package com.novasky.starlightdream;
import android.graphics.*;
import org.json.*;
import java.util.*;
public final class Samples {
 static long seed=900;
 static void line(Project p,int brush,int color,float size,float[][] points)throws Exception {Raster.Stroke s=new Raster.Stroke();s.brush=Brush.catalog().get(brush);s.color=color;s.size=size;s.seed=seed++;for(float[] xy:points)s.points.add(new float[]{xy[0],xy[1],1});p.commit(new JSONObject().put("type","stroke").put("layer",p.doc.current().id).put("stroke",s.json()),false);}
 static float[][] ellipse(float cx,float cy,float rx,float ry,float start,float end){float[][] p=new float[90][2];for(int i=0;i<p.length;i++){double a=Math.toRadians(start+(end-start)*i/(p.length-1));p[i][0]=cx+(float)Math.cos(a)*rx;p[i][1]=cy+(float)Math.sin(a)*ry;}return p;}
 public static void populate(Project p)throws Exception {
  p.commit(new JSONObject().put("type","background").put("color",0xff211b35),false);
  line(p,0,0xff85769f,6,ellipse(384,468,164,187,0,360));
  line(p,0,0xff85769f,4,new float[][]{{208,462},{566,462}});line(p,0,0xff85769f,4,new float[][]{{384,270},{384,667}});
  p.commit(new JSONObject().put("type","add").put("id","ink").put("name","Character ink"),false);
  line(p,10,0xfff3d9b5,12,ellipse(384,468,150,176,5,175));line(p,10,0xfff3d9b5,12,ellipse(384,468,150,176,175,365));
  line(p,15,0xffd9b8ff,22,new float[][]{{236,420},{235,350},{266,287},{328,251},{411,246},{489,288},{537,361},{532,441}});
  line(p,15,0xffd9b8ff,16,new float[][]{{257,405},{299,329},{337,371},{390,302},{434,366},{472,329},{518,416}});
  line(p,8,0xfff3d9b5,10,ellipse(323,464,30,18,180,360));line(p,8,0xfff3d9b5,10,ellipse(449,464,30,18,180,360));
  line(p,8,0xfff3d9b5,9,ellipse(384,538,44,25,0,180));
  line(p,8,0xfff3d9b5,9,new float[][]{{353,642},{350,691},{280,712},{238,760}});line(p,8,0xfff3d9b5,9,new float[][]{{415,642},{419,691},{488,712},{529,760}});
  p.commit(new JSONObject().put("type","add").put("id","stars").put("name","Starlight details"),false);
  line(p,48,0xffefc774,42,new float[][]{{142,219},{156,235}});line(p,48,0xffefc774,55,new float[][]{{605,280},{618,291}});line(p,56,0xffe8c7ff,34,new float[][]{{125,676},{183,802},{350,854},{552,821},{626,690}});
 }
}
