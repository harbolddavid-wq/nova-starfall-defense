#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:?Android SDK required}}"
T="$SDK/build-tools/35.0.0"
A="$SDK/platforms/android-35/android.jar"
mkdir -p build/classes build/dex build/generated build/runtime dist
"$T/aapt2" compile --dir app/src/main/res -o build/res.zip
"$T/aapt2" link -o build/base.apk --manifest app/src/main/AndroidManifest.xml -I "$A" -A app/src/main/assets --java build/generated build/res.zip
find app/src/main/java build/generated -name '*.java' > build/sources.list
javac --release 8 -cp "$A" -d build/classes @build/sources.list
java -cp "$T/lib/d8.jar" com.android.tools.r8.D8 --release --min-api 26 --lib "$A" --output build/dex $(find build/classes -name '*.class')
cp build/base.apk build/runtime/base.apk
(cd build/dex && zip -q -u ../runtime/base.apk *.dex)
"$T/zipalign" -f -p 4 build/runtime/base.apk dist/Starlights_Dream_0.3.1_unsigned_aligned.apk
cp "$T/lib/apksigner.jar" dist/apksigner.jar
# Build instrumentation tests against exactly this release's Java classes.
mkdir -p build/testsclasses build/testsdex build/testsout
find tests/src -name '*.java' > build/testsources.list
javac --release 8 -cp "$A:build/classes" -d build/testsclasses @build/testsources.list
java -cp "$T/lib/d8.jar" com.android.tools.r8.D8 --release --min-api 26 --lib "$A" --output build/testsdex $(find build/testsclasses -name '*.class')
"$T/aapt2" link -o build/testsout/base.apk --manifest tests/AndroidManifest.xml -I "$A"
(cd build/testsdex && zip -q -u ../testsout/base.apk *.dex)
"$T/zipalign" -f -p 4 build/testsout/base.apk dist/Starlights_Dream_0.3.1_Runtime_Tests_unsigned_aligned.apk
ls -lh dist/*.apk
