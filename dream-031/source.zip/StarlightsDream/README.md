# Starlight’s Dream 0.3.0 — standalone edition
For Desi, from Dad & Nova • October 24, 2026

A fresh-install release recovered from the original 0.2.2 source, with Desi’s new tools. Native Android drawing, offline, no account, ads, subscription or internet permission. Target phone: Samsung Galaxy A17 5G; BLU ViewPro 5G is a secondary test device.

## Install
Install Starlights_Dream_0.3.0.apk with your existing installer. This is a NEW app identity (com.novasky.starlightdream), signed with a new, backed-up key. It is not an in-place update for the old com.novasky.starlight installation. Both can coexist, with the same visible app name. Future updates to THIS edition must use its retained key and a higher versionCode.

If drawings remain on the old phone, export them as editable .dream files and import them through the new app’s Gallery. PNG copies are flattened; .dream preserves layers. Keep originals until imports are checked. No drawing data moves automatically between phones.

## Desi’s additions
- **Warp:** Tools → Warp selection / layer. Lasso first for a selected area, or leave no selection to use the whole layer. Drag the four corners to change perspective; Apply commits one undoable edit, Cancel restores the original. Pinch also scales/rotates. Folded/crossed corners are rejected. This is four-corner perspective deformation, not mesh/liquify.
- **Folders:** Layers → + Folder → choose member layers. Each remains independently editable. Tap the folder name → Move folder together, drag the preview and Apply. Undo restores all members together. Folder can show/hide all members or ungroup. Each layer’s Folder button changes membership. Folders are flat, not nested; group movement currently supports translation, not group rotation/warp. Locked members must be unlocked; cross-folder clipping must be resolved before movement. Moving pixels outside the canvas crops them on Apply; Undo restores them.
- **Color wheel:** Color opens the circular hue/saturation picker, brightness control, hex entry, preset swatches and saved colors.
- **Palettes:** Color → Save to palette creates a named palette or appends to one. Color → Saved palettes opens all named sets. Tap a swatch to use it, hold to remove. Rename/delete controls are included. Palettes persist on this installation across drawings and restarts; they are not embedded in exported .dream documents or automatically backed up to the cloud.
- **Color overlays:** Layers → Color overlay adjusts the entire canvas; Tint on a layer adjusts that layer. Choose color and amount, preview, Apply or Cancel. The adjustment preserves original pixels and transparency and is undoable. Amount 0 removes it. This is a color tint, not a full curves/HSL adjustment suite.
- **Nature and textures:** Brushes → Nature & masonry: Meadow grass, Fine grass, Daisy blossoms, Wildflower scatter, Brickwork and Rough stone. Masonry uses similar shades of the selected color; scatter/spacing can be customized. These are procedural stamped textures, not imported texture photographs.
- **Direct layer controls:** Every layer card now has a visible opacity slider, Visible/Hidden toggle, folder assignment and tint, alongside reordering/rename/merge.

## Preserved tools
Drawing/erasing with separate presets and size settings; 80 original brushes plus six new presets; custom brushes; undo/redo; layers, alpha lock and clipping; sketch protection; fill-reference controls; movable mirror; lasso/copy/move; zoom/pan/rotation; photo import/linework cleanup; editable local saves and .dream export; PNG and replay export.

Dedicated Atlas/Studio integration, package queries and receiving hooks were removed. Normal Android file import/export and Share remain available.

## Save compatibility
New .dream saves use format 2 to distinguish the new folder/tint events. This edition accepts old format 1 and new format 2 archives. Older Dream releases cannot open format 2; retain old originals. Save/load and undo coverage was added to Android instrumentation tests but has not been executed on a device in this session.

## Test status
APK compiled; v2/v3 signature verification and alignment passed. Thirteen warp geometry checks and five hair geometry checks passed on the JVM. Android regression tests, including new folder/tint/save/load checks, compiled and were packaged separately for developer execution. They were NOT run. Cloud Android execution returned quota_exhausted (resets November 1), so physical installation, touch layout, rendering and performance still need Desi/David’s test. No generated mockup is presented as a running screenshot.

See docs/PHONE_TEST.md for the first phone test and docs/BUILD_AND_RECOVERY.md for development.
