# Next session
1. Verify source files, PROJECT_STATUS and signing backup availability before edits.
2. Read Desi/David physical feedback. Test folder move/apply/cancel/undo, tint cancel/save/load, palette persistence and legacy .dream import first.
3. Run Android instrumentation on available emulator/device; do not confuse compilation with execution. Existing 0.3.0 tests cover 86 brushes, warp/mirror and added folder/tint/save/load behavior.
4. Preserve the new package com.novasky.starlightdream, use its existing private release key, increment versionCode. Never substitute a new key silently.
5. Preserve format 1 import and format 2 exports. Do not revive removed Atlas/Studio integration unless requested.
6. UI polish or expanded folder transforms can follow tested core behavior. Runtime screenshots must come from actual execution.
