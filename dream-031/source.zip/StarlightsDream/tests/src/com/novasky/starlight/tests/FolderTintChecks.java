package com.novasky.starlightdream.tests;
import com.novasky.starlightdream.*;
import android.graphics.*;
import org.json.*;
import java.io.*;
public final class FolderTintChecks {
 static int count;static void check(boolean ok,String text){if(!ok)throw new AssertionError(text);count++;}
 static JSONObject props(String id,String folder,int color,float amount)throws Exception{return new JSONObject().put("type","props").put("layer",id).put("props",new JSONObject().put("folder",folder).put("overlayColor",color).put("overlayAmount",amount));}
 public static int run(File root)throws Exception{
  count=0;Project p=Project.create(root,64,64,"Folder and tint");
  Raster.Stroke mark=new Raster.Stroke();mark.brush=Brush.catalog().get(8);mark.size=4;mark.color=Color.RED;mark.seed=1;mark.points.add(new float[]{20,20,1});
  p.commit(new JSONObject().put("type","stroke").put("layer","base").put("stroke",mark.json()),false);
  p.commit(new JSONObject().put("type","add").put("id","second"),false);
  mark.color=Color.BLUE;mark.points.clear();mark.points.add(new float[]{40,40,1});p.commit(new JSONObject().put("type","stroke").put("layer","second").put("stroke",mark.json()),false);
  p.commit(props("base","Pair",Color.WHITE,0),false);p.commit(props("second","Pair",Color.WHITE,0),false);
  Bitmap before=p.doc.flattened(false);int cursor=p.cursor;
  p.commit(new JSONObject().put("type","translateFolder").put("folder","Pair").put("dx",5).put("dy",7),false);
  check(p.doc.layers.size()==2,"folder move preserves separate layers");check(Color.alpha(p.doc.layer("base").pixels.getPixel(25,27))>0,"first member translated");check(Color.alpha(p.doc.layer("second").pixels.getPixel(45,47))>0,"second member translated");
  ArtDocument undone=p.rebuild(cursor);Bitmap undo=undone.flattened(false);check(before.sameAs(undo),"undo group move restores exact pixels");undo.recycle();undone.dispose();before.recycle();
  Bitmap raw=p.doc.layer("base").pixels.copy(Bitmap.Config.ARGB_8888,false);p.commit(props("base","Pair",Color.GREEN,1),false);Bitmap tinted=p.doc.flattened(false);check(Color.green(tinted.getPixel(25,27))>240,"layer tint applied");check(Color.alpha(tinted.getPixel(0,0))==0,"layer tint preserves transparency");check(raw.sameAs(p.doc.layer("base").pixels),"layer tint preserves original bitmap");tinted.recycle();raw.recycle();
  p.commit(new JSONObject().put("type","overlay").put("color",Color.YELLOW).put("amount",.5),false);
  Bitmap expected=p.doc.flattened(false);Project.Snapshot snapshot=p.snapshot();try{Project.save(snapshot);}finally{snapshot.dispose();}Project loaded=Project.load(p.dir);Bitmap actual=loaded.doc.flattened(false);check(actual.sameAs(expected),"save/load retains tint appearance");check(loaded.doc.layer("base").folder.equals("Pair")&&loaded.doc.layer("second").folder.equals("Pair"),"save/load retains membership");check(loaded.doc.overlayAmount==.5f,"canvas tint retained");actual.recycle();expected.recycle();loaded.doc.dispose();
  // A group mask includes the alpha of ALL member layers, not only one of them.
  p.commit(new JSONObject().put("type","add").put("id","paint"),false);
  p.commit(new JSONObject().put("type","fill").put("layer","paint").put("x",0).put("y",0).put("color",Color.MAGENTA),false);
  p.commit(new JSONObject().put("type","clipToFolder").put("layer","paint").put("folder","Pair"),false);
  check("Pair".equals(p.doc.layer("paint").clipFolder),"layer points at the entire folder mask");
  Bitmap all=p.doc.flattened(false);
  check(Color.alpha(all.getPixel(25,27))>0&&Color.alpha(all.getPixel(45,47))>0,"clipping reveals both group member shapes");
  check(Color.alpha(all.getPixel(4,4))==0,"group clipping blocks everything outside the group");all.recycle();
  p.commit(new JSONObject().put("type","folderProps").put("folder","Pair").put("props",new JSONObject().put("opacity",.5).put("visible",true)),false);
  check(Math.abs(p.doc.folder("Pair").opacity-.5f)<.001f,"group opacity stored separately from children");
  int afterGroupOpacity=p.cursor;
  p.commit(new JSONObject().put("type","folderProps").put("folder","Pair").put("props",new JSONObject().put("opacity",.5).put("visible",false)),false);
  Bitmap hidden=p.doc.flattened(false);check(Color.alpha(hidden.getPixel(25,27))==0,"hiding group hides clipped artwork too");hidden.recycle();
  ArtDocument reverted=p.rebuild(afterGroupOpacity);check(reverted.folder("Pair").visible,"undo can restore group visibility");reverted.dispose();
  Project.Snapshot later=p.snapshot();try{Project.save(later);}finally{later.dispose();}Project reopened=Project.load(p.dir);
  check("Pair".equals(reopened.doc.layer("paint").clipFolder)&&!reopened.doc.folder("Pair").visible,"full folder properties and clipping survive restart");reopened.doc.dispose();
  p.doc.dispose();return count;
 }
}
