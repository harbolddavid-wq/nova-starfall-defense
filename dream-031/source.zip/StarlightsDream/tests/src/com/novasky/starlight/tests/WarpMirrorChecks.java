package com.novasky.starlightdream.tests;
import android.content.Context;
import android.graphics.*;
import com.novasky.starlightdream.*;
import java.io.File;
import org.json.*;

/** Run on Android's main thread: exercises actual graphics and project history. */
public final class WarpMirrorChecks {
 static int checks;
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);checks++;}
 public static int run(Context context,File root)throws Exception{
  Project project=Project.create(root,128,128,"Warp and mirror");
  DrawingView.Host host=new DrawingView.Host(){public void changed(){}public void message(String s){}public void picked(int c){}};
  DrawingView view=new DrawingView(context,project,host);
  view.symmetryAxis=40;view.saveMirrorAxis();
  check(new DrawingView(context,project,host).symmetryAxis==40,"axis restored for this project");
  view.centerMirror();check(view.symmetryAxis==64,"center restores half width");
  Project separate=Project.create(root,128,128,"Separate mirror");
  check(new DrawingView(context,separate,host).symmetryAxis==64,"new drawing uses its own axis");separate.doc.dispose();
  Raster.Stroke stroke=new Raster.Stroke();stroke.brush=Brush.from(Brush.catalog().get(8).json());
  stroke.brush.kind="round";stroke.brush.aspect=1;stroke.brush.scatter=0;stroke.brush.jitter=0;stroke.brush.taper=0;stroke.brush.flow=1;
  stroke.size=6;stroke.color=Color.RED;stroke.seed=42;stroke.symmetry=true;stroke.symmetryAxis=40;stroke.points.add(new float[]{30,30,1});
  JSONObject json=stroke.json();Raster.Stroke restored=Raster.Stroke.from(json);
  check(restored.symmetryAxis==40,"axis retained in stroke serialization");
  project.commit(new JSONObject().put("type","stroke").put("layer","base").put("stroke",json),false);
  check(Color.alpha(project.doc.current().pixels.getPixel(50,30))>0&&project.doc.current().pixels.getPixel(98,30)==0,"off-center reflection uses new axis");
  ArtDocument rebuilt=project.rebuild(project.cursor);check(rebuilt.current().pixels.sameAs(project.doc.current().pixels),"rebuild preserves mirror pixels");rebuilt.dispose();
  json.remove("symmetryAxis");Bitmap legacy=project.doc.empty();Raster.stroke(legacy,Raster.Stroke.from(json),false,1);
  check(Color.alpha(legacy.getPixel(98,30))>0&&legacy.getPixel(50,30)==0,"legacy strokes still mirror at center");legacy.recycle();
  Bitmap original=project.doc.current().pixels.copy(Bitmap.Config.ARGB_8888,false);
  view.selectAll();check(view.floatSelection(true),"move enters warp-capable selection");
  check(view.setWarpCorner(0,20,10),"independent corner accepted");
  float[] corners=view.floatingCorners();check(Math.abs(corners[0]-20)<.01&&Math.abs(corners[1]-10)<.01&&Math.abs(corners[2]-128)<.01,"matrix maps selected corner and holds neighboring corner");
  check(!view.setWarpCorner(0,150,150),"fold rejected");
  view.resetWarp();check(Math.abs(view.floatingCorners()[0])<.01,"reset removes distortion");
  view.setWarpCorner(0,20,10);view.clearFloating();check(original.sameAs(project.doc.current().pixels),"discard warp leaves original pixels intact");
  view.selectAll();view.floatSelection(true);view.setWarpCorner(0,20,10);view.floatAngle=30;view.flipX=-1;view.floatScale=.8f;
  Matrix transform=view.floatingMatrix(),inverse=new Matrix();check(transform.invert(inverse),"warped rotated flipped selection remains invertible");
  float[] point={40,50};transform.mapPoints(point);inverse.mapPoints(point);check(Math.abs(point[0]-40)<.01&&Math.abs(point[1]-50)<.01,"combined perspective transform roundtrip");
  view.applyFloating();check(project.doc.layers.size()==1&&!original.sameAs(project.doc.current().pixels),"apply modifies same layer");
  ArtDocument undone=project.rebuild(project.cursor-1);check(original.sameAs(undone.current().pixels),"undo warp restores exact original");undone.dispose();
  Project.Snapshot snapshot=project.snapshot();Project.save(snapshot);snapshot.dispose();Project loaded=Project.load(project.dir);check(loaded.doc.current().pixels.sameAs(project.doc.current().pixels),"warp and mirror survive project save/load");loaded.doc.dispose();
  view.selectAll();check(view.floatSelection(false),"copy enters warp selection");view.setWarpCorner(0,8,12);view.applyFloating();
  ArtDocument copyRebuild=project.rebuild(project.cursor);check(copyRebuild.current().pixels.sameAs(project.doc.current().pixels),"copy perspective matrix survives recorded history");copyRebuild.dispose();
  original.recycle();project.doc.dispose();return checks;
 }
}
