"""Execute actual Raster reference-fill pixel algorithm with JVM pixel-buffer adapters.
This tests region traversal and destination writes, not Android UI/Bitmap integration.
"""
from pathlib import Path
import argparse,subprocess,tempfile
parser=argparse.ArgumentParser();parser.add_argument('--compiler',required=True);args=parser.parse_args()
source=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/novasky/starlight/Raster.java').read_text()
algorithm=source[source.index(' public static void fillUsingReference('):source.rfind('\n}')]
java='''import java.util.*;
public class ReferenceFillCheck {
static class Color {static int alpha(int c){return c>>>24;}static int red(int c){return c>>16&255;}static int green(int c){return c>>8&255;}static int blue(int c){return c&255;}}
static class Bitmap {int w,h;int[] p;Bitmap(int w,int h){this.w=w;this.h=h;p=new int[w*h];}int getWidth(){return w;}int getHeight(){return h;}void getPixels(int[] d,int o,int stride,int x,int y,int w,int h){for(int j=0;j<h;j++)System.arraycopy(p,(y+j)*this.w+x,d,o+j*stride,w);}void setPixels(int[] d,int o,int stride,int x,int y,int w,int h){for(int j=0;j<h;j++)System.arraycopy(d,o+j*stride,p,(y+j)*this.w+x,w);}}
static int checks=0;static void check(boolean b,String label){if(!b)throw new AssertionError(label);checks++;System.out.println("PASS "+label);}
static Bitmap outline(boolean paper){Bitmap b=new Bitmap(12,12);if(paper)Arrays.fill(b.p,0xffffffff);for(int i=2;i<=9;i++){b.p[2*12+i]=b.p[9*12+i]=b.p[i*12+2]=b.p[i*12+9]=0xff000000;}return b;}
public static void main(String[] args){
 Bitmap line=outline(false),color=new Bitmap(12,12);int[] original=line.p.clone();fillUsingReference(color,line,5,5,0xffff0000,24,false);
 check(color.p[5*12+5]==0xffff0000,"color goes onto separate destination layer");check(color.p[0]==0&&color.p[2*12+5]==0,"linework boundary prevents fill leaking outside");check(Arrays.equals(line.p,original),"reference linework stays unchanged");
 fillUsingReference(color,line,5,5,0xff00ff00,24,false);check(color.p[5*12+5]==0xff00ff00&&color.p[0]==0,"same outlined region can be recolored");
 Bitmap whitePaper=outline(true),white=new Bitmap(12,12);fillUsingReference(white,whitePaper,5,5,0xffffffff,24,false);check(white.p[5*12+5]==0xffffffff&&white.p[0]==0,"white fill works even when reference seed is already white");
 Bitmap locked=new Bitmap(12,12);locked.p[5*12+5]=0x80443322;fillUsingReference(locked,line,4,4,0xff00ff00,24,true);check(locked.p[5*12+5]==0x8000ff00&&locked.p[4*12+4]==0,"alpha lock retains destination alpha and traverses unpainted region");
 int[] before=color.p.clone();fillUsingReference(color,line,-1,4,0xff000000,24,false);check(Arrays.equals(before,color.p),"out-of-canvas tap leaves destination unchanged");
 Bitmap expanded=new Bitmap(12,12);fillUsingReference(expanded,line,5,5,0xffff0000,24,false,2);
 check(expanded.p[1*12+5]==0xffff0000&&expanded.p[0*12+5]==0,"two-pixel overlap extends exactly two pixels past region");
 check(Arrays.equals(line.p,original),"overlap leaves reference pixels unchanged");
 Bitmap edge=new Bitmap(3,3);fillUsingReference(edge,edge,0,0,0xff123456,0,false,8);boolean all=true;for(int v:edge.p)all&=v==0xff123456;check(all,"overlap handles canvas edges and tiny canvases");
 Bitmap lockOverlap=new Bitmap(12,12);lockOverlap.p[2*12+5]=0x60443322;fillUsingReference(lockOverlap,line,5,5,0xffabcdef,24,true,2);check(lockOverlap.p[2*12+5]==0x60abcdef&&lockOverlap.p[1*12+5]==0,"expanded fill obeys alpha lock at boundary");
 boolean correct=true;Random random=new Random(74);for(int w=1;w<=12;w++)for(int h=1;h<=12;h++)for(int radius=0;radius<=8;radius++){boolean[] mask=new boolean[w*h];for(int i=0;i<mask.length;i++)mask[i]=random.nextInt(7)==0;boolean[] actual=mask.clone();expandFillRegion(actual,w,h,radius);for(int y=0;y<h;y++)for(int x=0;x<w;x++){boolean wanted=false;for(int yy=Math.max(0,y-radius);yy<=Math.min(h-1,y+radius);yy++)for(int xx=Math.max(0,x-radius);xx<=Math.min(w-1,x+radius);xx++)wanted|=mask[yy*w+xx];correct&=actual[y*w+x]==wanted;}}check(correct,"sliding expansion matches brute-force geometry across 1296 cases");
 boolean middles=true,noLeaks=true,noSeams=true,unchanged=true;
 for(boolean paper:new boolean[]{false,true})for(int thickness=1;thickness<=15;thickness++){
  Bitmap ref=new Bitmap(50,50);if(paper)Arrays.fill(ref.p,0xffffffff);
  for(int y=0;y<50;y++)for(int x=14;x<14+thickness;x++)ref.p[y*50+x]=0xff000000;
  int[] saved=ref.p.clone();Bitmap left=new Bitmap(50,50),right=new Bitmap(50,50);
  fillUsingReference(left,ref,5,25,0xffff0000,24,false,-1);fillUsingReference(right,ref,45,25,0xff00ff00,24,false,-1);
  int last=14+(thickness-1)/2;middles&=left.p[25*50+last]==0xffff0000&&left.p[25*50+last+1]==0;
  for(int y=0;y<50;y++)for(int x=14+thickness;x<50;x++)noLeaks&=left.p[y*50+x]==0;
  for(int x=14;x<14+thickness;x++)noSeams&=left.p[25*50+x]!=0||right.p[25*50+x]!=0;
  unchanged&=Arrays.equals(saved,ref.p);
 }
 check(middles,"auto reaches middle for 1 to 15 pixel lines on transparent and white references");check(noLeaks,"auto never paints neighbouring empty region");check(noSeams,"adjacent auto fills meet without a centre seam");check(unchanged,"auto leaves all reference linework unchanged");
 Bitmap soft=new Bitmap(50,50);for(int y=0;y<50;y++)for(int x=14;x<=20;x++)soft.p[y*50+x]=(x==14||x==20)?0x60000000:0xff000000;
 Bitmap softFill=new Bitmap(50,50);fillUsingReference(softFill,soft,5,25,0xffff0000,24,false,-1);check(softFill.p[25*50+14]!=0&&softFill.p[25*50+17]!=0&&softFill.p[25*50+18]==0,"auto covers inner antialias fringe and stops at centre");
 Bitmap smartLocked=new Bitmap(50,50);smartLocked.p[25*50+17]=0x60443322;fillUsingReference(smartLocked,soft,5,25,0xffabcdef,24,true,-1);check(smartLocked.p[25*50+17]==0x60abcdef&&smartLocked.p[25*50+16]==0,"auto preserves alpha lock beneath line");
 Bitmap same=outline(false);int ink=same.p[2*12+5];fillUsingReference(same,same,5,5,0xffff0000,24,false,-1);check(same.p[2*12+5]==ink&&same.p[5*12+5]==0xffff0000,"auto current-layer fill preserves line pixels");
 Bitmap diagonal=new Bitmap(60,60);for(int y=0;y<60;y++)for(int x=0;x<60;x++)if(Math.abs(x-y)<=4)diagonal.p[y*60+x]=0xff000000;
 Bitmap diagColor=new Bitmap(60,60);fillUsingReference(diagColor,diagonal,10,30,0xffff0000,24,false,-1);check(diagColor.p[30*60+28]!=0&&diagColor.p[30*60+33]==0&&diagColor.p[30*60+40]==0,"auto follows diagonal line middle");
 Bitmap ring=new Bitmap(80,80);for(int y=0;y<80;y++)for(int x=0;x<80;x++){double r=Math.hypot(x-40,y-40);if(r>=20&&r<=28)ring.p[y*80+x]=0xff000000;}
 Bitmap ringFill=new Bitmap(80,80);fillUsingReference(ringFill,ring,40,40,0xffff0000,24,false,-1);boolean ringSafe=true;for(int y=0;y<80;y++)for(int x=0;x<80;x++)if(Math.hypot(x-40,y-40)>28)ringSafe&=ringFill.p[y*80+x]==0;check(ringSafe&&ringFill.p[40*80+63]!=0&&ringFill.p[40*80+67]==0,"auto follows curved line thickness without escaping");
 System.out.println(checks+" reference-fill algorithm checks passed.");}
'''+algorithm+'\n}'
with tempfile.TemporaryDirectory() as work:
 path=Path(work)/'ReferenceFillCheck.java';path.write_text(java)
 subprocess.run(['java','-jar',args.compiler,'-8','-proc:none','-d',work,str(path)],check=True)
 subprocess.run(['java','-cp',work,'ReferenceFillCheck'],check=True)
