import com.novasky.starlightdream.ExportFiles;
import java.io.*;
import java.nio.file.*;
import java.util.*;
public class ExportFilesCheck {
 static int checks;static void check(boolean ok,String text){if(!ok)throw new AssertionError(text);checks++;System.out.println("PASS "+text);}
 static class Target implements ExportFiles.Destination {
  ByteArrayOutputStream bytes=new ByteArrayOutputStream();boolean closed,published,discarded;int fail;Target(int f){fail=f;}
  public OutputStream open()throws Exception{if(fail==1)return null;return new OutputStream(){public void write(int b)throws IOException{if(fail==2)throw new IOException("full");bytes.write(b);}public void close()throws IOException{closed=true;if(fail==3)throw new IOException("close failed");}};}
  public void publish()throws Exception{if(!closed)throw new AssertionError("published before close");if(fail==4)throw new IOException("publish failed");published=true;}
  public void discard(){discarded=true;}
 }
 public static void main(String[] args)throws Exception{
  Path dir=Files.createTempDirectory("export-check");try{
   File source=dir.resolve("drawing.png").toFile();byte[] input=new byte[180123];new Random(31).nextBytes(input);Files.write(source.toPath(),input);
   Target ok=new Target(0);ExportFiles.write(source,ok);check(ok.published&&ok.closed&&!ok.discarded&&Arrays.equals(input,ok.bytes.toByteArray()),"large export copies exactly and publishes after closing");
   for(int fail=1;fail<=4;fail++){Target target=new Target(fail);boolean threw=false;try{ExportFiles.write(source,target);}catch(Exception e){threw=true;}check(threw&&target.discarded&&!target.published&&Arrays.equals(input,Files.readAllBytes(source.toPath())),"failure "+fail+" cleans destination and preserves source for retry");}
   Target missing=new Target(0);try{ExportFiles.write(dir.resolve("missing.png").toFile(),missing);}catch(IOException e){}check(missing.discarded&&!missing.published,"missing source cannot report success");
   File empty=dir.resolve("empty.png").toFile();Files.write(empty.toPath(),new byte[0]);Target blank=new Target(0);try{ExportFiles.write(empty,blank);}catch(IOException e){}check(blank.discarded&&!blank.published,"empty export cannot report success");
   System.out.println(checks+" export IO checks passed");
  }finally{for(File f:dir.toFile().listFiles())f.delete();Files.delete(dir);}
 }
}
