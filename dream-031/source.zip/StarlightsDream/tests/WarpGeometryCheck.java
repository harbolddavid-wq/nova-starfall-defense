import com.novasky.starlightdream.WarpGeometry;
public class WarpGeometryCheck {
 static int checks;
 static void check(boolean value,String label){if(!value)throw new AssertionError(label);checks++;}
 public static void main(String[] args){
  check(WarpGeometry.valid(new float[]{0,0,100,0,100,100,0,100}),"rectangle");
  check(WarpGeometry.valid(new float[]{20,10,80,10,100,100,0,100}),"perspective trapezoid");
  check(WarpGeometry.valid(new float[]{-30,-10,100,0,100,100,0,100}),"outside original bounds");
  check(WarpGeometry.valid(new float[]{0,0,1,0,1,1,0,1}),"one pixel selection");
  check(!WarpGeometry.valid(new float[]{0,0,100,100,100,0,0,100}),"crossing corners");
  check(!WarpGeometry.valid(new float[]{0,0,100,0,20,20,0,100}),"inward fold");
  check(!WarpGeometry.valid(new float[]{0,0,0,0,100,100,0,100}),"collapsed edge");
  check(!WarpGeometry.valid(new float[]{0,0,100,0,200,0,0,100}),"collinear edge");
  check(!WarpGeometry.valid(new float[]{Float.NaN,0,100,0,100,100,0,100}),"NaN");
  check(!WarpGeometry.valid(new float[]{Float.POSITIVE_INFINITY,0,100,0,100,100,0,100}),"infinite");
  check(!WarpGeometry.valid(new float[]{-100001,0,100,0,100,100,0,100}),"unstable extreme");
  check(!WarpGeometry.valid(new float[]{0,0}),"incomplete");
  check(!WarpGeometry.valid(null),"missing");
  System.out.println(checks+" warp geometry checks passed");
 }
}
