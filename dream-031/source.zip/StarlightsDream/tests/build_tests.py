from pathlib import Path
import os,subprocess,zipfile,shutil
r=Path(__file__).resolve().parents[1]
t=Path(os.environ.get('NOVA_BUILD_TOOLS',str(r.parents[1]/'android-toolchain/sdk/android-15')))
a=Path(os.environ.get('NOVA_ANDROID_JAR',str(r.parents[1]/'android-toolchain/sdk/android-35/android.jar')))
s=Path(os.environ.get('NOVA_SIGNING_DIR',str(r.parents[1]/'dream-private-signing')))
b=r/'build/tests';shutil.rmtree(b,ignore_errors=True);(b/'classes').mkdir(parents=True);(b/'dex').mkdir()
def run(*args):subprocess.run([str(x) for x in args],check=True)
run('java','-m','jdk.compiler/com.sun.tools.javac.Main','--release','8','-cp',str(a)+':'+str(r/'build/classes'),'-d',b/'classes',*sorted((r/'tests/src').rglob('*.java')))
run('java','-cp',t/'lib/d8.jar','com.android.tools.r8.D8','--lib',a,'--min-api','26','--output',b/'dex',*sorted((b/'classes').rglob('*.class')))
run(t/'aapt2','link','-I',a,'--manifest',r/'tests/AndroidManifest.xml','-o',b/'base.apk')
with zipfile.ZipFile(b/'base.apk','a',zipfile.ZIP_DEFLATED) as z:
 for p in (b/'dex').glob('*.dex'):z.write(p,p.name)
run(t/'zipalign','-f','4',b/'base.apk',b/'aligned.apk')
run('java','-jar',t/'lib/apksigner.jar','sign','--ks',s/'release.p12','--ks-key-alias','starlight','--ks-pass','file:'+str(s/'password'),'--out',r/'dist/Starlights_Dream_Runtime_Tests.apk',b/'aligned.apk')
print('Instrumentation compiled, not executed. Install main APK plus test APK, then adb shell am instrument -w com.novasky.starlightdream.tests/com.novasky.starlightdream.tests.RuntimeTests')
