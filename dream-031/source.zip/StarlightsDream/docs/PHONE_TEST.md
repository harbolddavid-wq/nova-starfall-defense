# First phone test — 0.3.0

Use a new test drawing before importing treasured work. None of these are marked passed yet.

1. Install and launch; create a small canvas. Draw, erase, undo and redo. Check the keyboard and navigation bar do not cover controls.
2. Put different marks on two layers. Create a folder containing both. Move the folder, Apply, then Undo/Redo. Both marks should move together while each layer remains editable. Cancel another move and check neither changes.
3. Lasso part of a layer; Tools → Warp selection / layer. Drag a corner, Apply, Undo, Redo. Try Reset and Cancel.
4. Change each layer’s opacity directly in Layers; toggle visibility; move a layer up/down. Check no hidden merge occurs.
5. Pick a color with wheel/brightness and hex. Save several swatches into two named palettes. Close/reopen the app and select them again.
6. Apply a layer tint and whole-canvas tint. Cancel another tint, then check appearance. Remove a tint using amount 0. Undo and redo the committed adjustment.
7. Try all six Nature & masonry brushes at different sizes. Brick/stone should vary mostly in shade, not random hues.
8. Save, return to Gallery, reopen. Export .dream, import the copy, and compare layers, folder membership, tint appearance and editable pixels. Export PNG and inspect it in Gallery.
9. Import a COPY of an old .dream file; verify it before transferring more. Keep the old phone/original archive.
10. Rotate and background/reopen during normal drawing; check saves. Try photo import and PNG/replay export. Report the action and screenshot if something fails.

Temporary tint previews cancel when the app leaves the foreground. Use Apply before switching apps if you want to keep the adjustment. No runtime result from another Nova app counts as verification for this release.
