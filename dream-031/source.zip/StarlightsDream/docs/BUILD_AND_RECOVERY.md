# Reproducible build and signing recovery

Use JDK 17 and Android platform 35. Supply compatible Android build tools with aapt2, zipalign, lib/d8.jar and lib/apksigner.jar.

Environment:
- NOVA_ANDROID_JAR: full path to platform 35 android.jar.
- NOVA_BUILD_TOOLS: directory containing the above build tools.
- NOVA_SIGNING_DIR: PRIVATE directory containing release.p12 and password, alias starlight.

Run `python3 build.py`. It compiles native Java sources, packages resources/assets, generates DEX, aligns, signs and verifies dist/Starlights_Dream_0.3.0.apk. No download is performed. Gradle configuration is supplied for editing; build.py is the verified packaging path.

The separately saved Starlights_Dream_PRIVATE_Signing_Recovery.zip contains the release key AND its password. It is private development material; never place it in source ZIPs, public repositories or the app itself. Keep a second offline copy in secure storage. Restoring it means extracting to a private directory and setting NOVA_SIGNING_DIR. Never regenerate the key for an update. Increment manifest and Gradle versionCode/name together and adjust output filename. Verify the signer matches the prior release before delivery.

New application ID: com.novasky.starlightdream. This release uses versionCode 1, versionName 0.3.0. Original Dream had a DIFFERENT ID and key; this key cannot update it.

Source contains tests but no signing credentials. Android instrumentation build: run `python3 tests/build_tests.py` after the main build. On an available device with adb, install the main APK and test APK then run:
`adb shell am instrument -w com.novasky.starlightdream.tests/com.novasky.starlightdream.tests.RuntimeTests`
Instrumentation currently has only been compiled, not run.

Host geometry checks: compile WarpGeometry.java, HairGeometry.java and their corresponding tests/*Check.java with javac --release 8; run WarpGeometryCheck and HairGeometryCheck. No Android device needed for those two checks.

Existing dependency/toolchain lock files record the recovered project's historical build setup. BUILD_ENVIRONMENT.json records checksums for the tools used in this release. Do not mistake historical test reports under qa for a 0.3.0 runtime result.
