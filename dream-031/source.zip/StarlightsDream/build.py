from pathlib import Path
import os,subprocess,zipfile,shutil
R=Path(__file__).resolve().parent;SDK=Path(os.environ.get('NOVA_ANDROID_SDK',str(R.parents[1]/'android-toolchain/sdk')));T=Path(os.environ.get('NOVA_BUILD_TOOLS',str(SDK/'android-15')));A=Path(os.environ.get('NOVA_ANDROID_JAR',str(SDK/'android-35/android.jar')));B=R/'build';O=R/'dist';S=Path(os.environ.get('NOVA_SIGNING_DIR',str(R.parents[1]/'dream-private-signing')))
def run(args):
 if Path(str(args[0])).is_file():Path(args[0]).chmod(0o755)
 subprocess.run(list(map(str,args)),check=True)
shutil.rmtree(B,ignore_errors=True);(B/'classes').mkdir(parents=True);(B/'dex').mkdir();O.mkdir(exist_ok=True);src=R/'app/src/main'
run([T/'aapt2','compile','--dir',src/'res','-o',B/'res.zip'])
run([T/'aapt2','link','-o',B/'base.apk','--manifest',src/'AndroidManifest.xml','-I',A,'-A',src/'assets','--java',B/'generated',B/'res.zip'])
run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','--release','8','-cp',A,'-d',B/'classes',*sorted((src/'java').rglob('*.java')),*sorted((B/'generated').rglob('*.java'))])
run(['java','-cp',T/'lib/d8.jar','com.android.tools.r8.D8','--release','--min-api','26','--lib',A,'--output',B/'dex',*sorted((B/'classes').rglob('*.class'))])
with zipfile.ZipFile(B/'base.apk','a',zipfile.ZIP_DEFLATED) as z:
 for f in (B/'dex').glob('*.dex'):z.write(f,f.name)
run([T/'zipalign','-f','4',B/'base.apk',B/'aligned.apk'])
run(['java','-jar',T/'lib/apksigner.jar','sign','--ks',S/'release.p12','--ks-key-alias','starlight','--ks-pass','file:'+str(S/'password'),'--out',O/'Starlights_Dream_0.3.0.apk',B/'aligned.apk'])
run(['java','-jar',T/'lib/apksigner.jar','verify','--verbose',O/'Starlights_Dream_0.3.0.apk'])
