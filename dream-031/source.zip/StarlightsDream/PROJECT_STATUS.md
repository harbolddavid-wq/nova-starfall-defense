# Starlight’s Dream — version 0.3.1 feedback patch

Desi’s Galaxy A17 5G bug fixes:
- Tint starts at a useful strength (55% instead of 0) when first opened, previews immediately, and explicitly saves when applied.
- Folders are composited as one isolated image while preserving editable child layer bitmaps.
- Tap folder row to expand or collapse it; the group itself has visibility and opacity controls, move-as-one, and Ungroup.
- Separate layers can clip to the entire folder’s combined alpha, not just the layer below. They remain independently editable.
- Folder metadata and clipping persist in editable `.dream` format 2 saves. Legacy format 1 import remains supported.
- All original drawing tools, painting, warp, brushes and palette functionality preserved.
- Note: a clipped external layer is moved immediately above the target folder when group clipping is assigned so the mask is below it.
- Group masks and group-opacity updates are distinct from individual member pixels.

Build and tests: Android compilation and tests must still be verified by GitHub Actions and on the Galaxy A17 5G. The independent local model tests included in the source cover mask shape, hide, undo and save/reopen. These aren't a substitute for on-device testing.

# Project status — October 24, 2026

0.3.0 standalone fresh-install candidate built from recovered original 0.2.2 source. New signing identity generated and persisted privately BEFORE delivery. Old app connections removed.

Implemented: preserved corner warp/movable mirror; flat layer folders with independent pixels and touch translation; direct per-layer opacity/visibility; named palettes; nondestructive layer/canvas tint; six nature/masonry brushes. New format 2 saves accept old format 1 imports.

Passed: compilation, signing, alignment; 13 warp + 5 hair JVM checks. Android regression tests compile but are UNEXECUTED. Cloud emulator quota exhausted until Nov 1. Await physical phone feedback; do not label as fully runtime-tested.

Known scope: no nested folders, group rotation/warp, mesh/liquify or palette file export yet. Palettes are app-local. Canvas crop on moving outside bounds is undoable. Full integration removed as requested.

Original recovered files remain in Library; new source saved separately. No original key recovered; new identity is deliberate because Desi has a new phone. No GitHub backup made.
